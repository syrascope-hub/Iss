import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'orbit.dart';

void _txt(Canvas c, String t, Offset o, Color col, {double size = 12}) {
  final tp = TextPainter(
      text: TextSpan(text: t, style: TextStyle(color: col, fontSize: size)), textDirection: TextDirection.ltr)
    ..layout();
  tp.paint(c, o - Offset(tp.width / 2, tp.height / 2));
}

/// منظر السماء: مسار المرور (سمت/ارتفاع) والشمال في الأعلى.
class SkyPainter extends CustomPainter {
  final List<Look> pts;
  final Look? cur;
  final Color fg, accent;
  SkyPainter(this.pts, this.cur, this.fg, this.accent);

  @override
  void paint(Canvas c, Size s) {
    final r = math.min(s.width, s.height) / 2 - 20;
    final ctr = Offset(s.width / 2, s.height / 2);
    final grid = Paint()
      ..style = PaintingStyle.stroke
      ..color = fg.withOpacity(0.3)
      ..strokeWidth = 1;
    for (final e in [0.0, 30.0, 60.0]) {
      c.drawCircle(ctr, r * (90 - e) / 90, grid);
    }
    c.drawLine(ctr + Offset(0, -r), ctr + Offset(0, r), grid);
    c.drawLine(ctr + Offset(-r, 0), ctr + Offset(r, 0), grid);
    _txt(c, 'N', ctr + Offset(0, -r - 11), fg);
    _txt(c, 'S', ctr + Offset(0, r + 11), fg);
    _txt(c, 'E', ctr + Offset(r + 11, 0), fg);
    _txt(c, 'W', ctr + Offset(-r - 11, 0), fg);
    _txt(c, '30°', ctr + Offset(0, -r * 60 / 90 + 8), fg.withOpacity(0.6), size: 9);
    Offset at(Look l) {
      final rr = r * (90 - math.max(0.0, math.min(90.0, l.el))) / 90;
      final a = l.az * rad;
      return Offset(ctr.dx + rr * math.sin(a), ctr.dy - rr * math.cos(a));
    }

    if (pts.length > 1) {
      final path = Path()..moveTo(at(pts.first).dx, at(pts.first).dy);
      for (final p in pts.skip(1)) {
        final o = at(p);
        path.lineTo(o.dx, o.dy);
      }
      c.drawPath(
          path,
          Paint()
            ..style = PaintingStyle.stroke
            ..color = accent
            ..strokeWidth = 3);
      c.drawCircle(at(pts.first), 4, Paint()..color = Colors.green);
      c.drawCircle(at(pts.last), 4, Paint()..color = Colors.red);
    }
    final k = cur;
    if (k != null && k.el > 0) {
      c.drawCircle(at(k), 7, Paint()..color = Colors.red);
      c.drawCircle(
          at(k),
          10,
          Paint()
            ..style = PaintingStyle.stroke
            ..color = Colors.red
            ..strokeWidth = 2);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => true;
}

/// انحراف Doppler (هرتز) عبر زمن المرور مع علامة اللحظة الحالية.
class DopplerPainter extends CustomPainter {
  final List<double> ts, df;
  final double nowT;
  final Color fg, accent;
  DopplerPainter(this.ts, this.df, this.nowT, this.fg, this.accent);

  @override
  void paint(Canvas c, Size s) {
    if (ts.length < 2) return;
    const pl = 46.0, pr = 8.0, pt = 8.0, pb = 8.0;
    final w = s.width - pl - pr, h = s.height - pt - pb;
    double mx = 1;
    for (final v in df) {
      mx = math.max(mx, v.abs());
    }
    mx *= 1.1;
    final t0 = ts.first, t1 = ts.last;
    double X(double t) => pl + w * (t - t0) / (t1 - t0);
    double Y(double v) => pt + h / 2 - (v / mx) * (h / 2);
    final grid = Paint()
      ..style = PaintingStyle.stroke
      ..color = fg.withOpacity(0.3)
      ..strokeWidth = 1;
    c.drawLine(Offset(pl, Y(0)), Offset(pl + w, Y(0)), grid);
    c.drawRect(Rect.fromLTWH(pl, pt, w, h), grid);
    _txt(c, '+${(mx / 1000).toStringAsFixed(1)}k', Offset(pl / 2, pt + 6), fg, size: 10);
    _txt(c, '-${(mx / 1000).toStringAsFixed(1)}k', Offset(pl / 2, pt + h - 6), fg, size: 10);
    _txt(c, '0', Offset(pl / 2, Y(0)), fg, size: 10);
    final path = Path()..moveTo(X(ts.first), Y(df.first));
    for (int i = 1; i < ts.length; i++) {
      path.lineTo(X(ts[i]), Y(df[i]));
    }
    c.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..color = accent
          ..strokeWidth = 2.5);
    if (nowT >= t0 && nowT <= t1) {
      final x = X(nowT);
      c.drawLine(Offset(x, pt), Offset(x, pt + h), Paint()..color = Colors.red..strokeWidth = 1.5);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => true;
}
