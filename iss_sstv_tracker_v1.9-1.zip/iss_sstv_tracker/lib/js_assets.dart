// مولَّد تلقائيًا من ملفات JS المُختبرة — لا تعدّله يدويًا
const hookJs = r'''
/* يُحقن في صفحة المحطة: يعترض خرج Web Audio ليوفّر: مستوى الصوت، Squelch، قياس المستوى،
 * التسجيل (PCM)، وتغذية فك SSTV. الإعدادات في window.__issCfg */
(function () {
  if (window.__issHook) return;
  window.__issHook = 1;
  var C = window.__issCfg = window.__issCfg || { vol: 1, sq: 0, sstv: 1, enh: 1 };
  var oc = AudioNode.prototype.connect, od = AudioNode.prototype.disconnect;
  var E = [], rec = false;

  function active() {
    var b = null;
    for (var i = 0; i < E.length; i++) { if (!b || E[i].lvl >= b.lvl) b = E[i]; }
    return b;
  }
  function gv(e) {
    var v = C.vol == null ? 1 : +C.vol;
    return (C.sq > 0 && !e.open) ? 0 : v;
  }
  function mk(ctx) {
    var e = {
      ctx: ctx, lvl: 0, open: true, closeN: 0,
      pre: ctx.createGain(), mg: ctx.createGain(),
      sp: ctx.createScriptProcessor(4096, 1, 1), mu: ctx.createGain()
    };
    e.mu.gain.value = 0;
    e.mg.gain.value = gv(e);
    oc.call(e.pre, e.mg); oc.call(e.mg, ctx.destination);
    oc.call(e.pre, e.sp); oc.call(e.sp, e.mu); oc.call(e.mu, ctx.destination);
    e.sp.onaudioprocess = function (ev) {
      var d = ev.inputBuffer.getChannelData(0), n = d.length, q = 0, k;
      for (k = 0; k < n; k += 4) { q += d[k] * d[k]; }
      var l = Math.sqrt(q / (n / 4));
      e.lvl = l;
      if (C.sq > 0) {
        if (l >= C.sq) { e.open = true; e.closeN = 0; }
        else if (e.open && ++e.closeN >= 4) { e.open = false; }
      } else { e.open = true; }
      var g = gv(e);
      if (e.mg.gain.value !== g) e.mg.gain.value = g;
      if (active() !== e) return;
      if (C.sstv !== 0 && window.__sstv) {
        try { window.__sstv.push(d, e.ctx.sampleRate); } catch (x) {}
      }
      if (!rec) return;
      var b = new Uint8Array(n * 2), v = new DataView(b.buffer);
      for (var i = 0; i < n; i++) {
        var s = d[i]; s = s > 1 ? 1 : (s < -1 ? -1 : s);
        v.setInt16(i * 2, s < 0 ? s * 32768 : s * 32767, true);
      }
      var str = '';
      for (var j = 0; j < b.length; j += 8192) { str += String.fromCharCode.apply(null, b.subarray(j, j + 8192)); }
      Rec.postMessage('D' + btoa(str));
    };
    E.push(e);
    return e;
  }

  AudioNode.prototype.connect = function (dest) {
    try {
      if (dest && window.AudioDestinationNode && dest instanceof AudioDestinationNode && this.context === dest.context) {
        var e = dest.__issE || (dest.__issE = mk(dest.context));
        var a = Array.prototype.slice.call(arguments);
        a[0] = e.pre;
        return oc.apply(this, a);
      }
    } catch (x) {}
    return oc.apply(this, arguments);
  };
  AudioNode.prototype.disconnect = function (dest) {
    try {
      if (dest && dest.__issE && this.context === dest.context) {
        var a = Array.prototype.slice.call(arguments);
        a[0] = dest.__issE.pre;
        return od.apply(this, a);
      }
    } catch (x) {}
    return od.apply(this, arguments);
  };

  window.__issRec = {
    start: function () {
      var a = active();
      if (!a) { Rec.postMessage('N'); return; }
      try { if (a.ctx.state === 'suspended') a.ctx.resume(); } catch (x) {}
      Rec.postMessage('S' + a.ctx.sampleRate);
      rec = true;
    },
    stop: function () { rec = false; },
    state: function () {
      var a = active();
      if (!a) return 'no-ctx';
      try { if (a.ctx.state === 'suspended') a.ctx.resume(); } catch (x) {}
      return a.ctx.state + '|' + a.ctx.sampleRate + '|' + a.lvl.toFixed(4) + '|' + (a.open ? 1 : 0);
    },
    apply: function () {
      for (var i = 0; i < E.length; i++) E[i].mg.gain.value = gv(E[i]);
    }
  };
})();

''';

const sstvJs = r'''
/* فك SSTV متدفّق: PD50/90/120/160/180/240/290 ، Robot36/72 ، Martin M1/M2 ، Scottie S1/S2
 * المدخل: عينات صوت أحادية (Float32 بين -1 و1) ومعدل العينة.
 * يعمل في المتصفح وفي Node (للاختبار). */
(function (root) {
  'use strict';
  var TWO_PI = 2 * Math.PI;

  function PD(name, w, h, px) {
    var seg = w * px;
    return { name: name, kind: 'pd', w: w, h: h, sync: 20, px: px, seg: seg, line: 22.08 + 4 * seg, lines: h / 2 };
  }
  var MODES = {
    93: PD('PD50', 320, 256, 0.286),
    99: PD('PD90', 320, 256, 0.532),
    95: PD('PD120', 640, 496, 0.190),
    98: PD('PD160', 512, 400, 0.382),
    96: PD('PD180', 640, 496, 0.286),
    97: PD('PD240', 640, 496, 0.382),
    94: PD('PD290', 800, 616, 0.286),
    8: { name: 'Robot36', kind: 'r36', w: 320, h: 240, sync: 9, line: 150, lines: 240 },
    12: { name: 'Robot72', kind: 'r72', w: 320, h: 240, sync: 9, line: 300, lines: 240 },
    44: { name: 'Martin M1', kind: 'mar', w: 320, h: 256, sync: 4.862, px: 0.4576, line: 446.446, lines: 256 },
    40: { name: 'Martin M2', kind: 'mar', w: 320, h: 256, sync: 4.862, px: 0.2288, line: 226.798, lines: 256 },
    60: { name: 'Scottie S1', kind: 'sco', w: 320, h: 256, sync: 9, px: 0.432, line: 428.38, lines: 256 },
    56: { name: 'Scottie S2', kind: 'sco', w: 320, h: 256, sync: 9, px: 0.2752, line: 277.692, lines: 256 }
  };

  function SstvDecoder(fs, cb) {
    this.fs = fs;
    this.cb = cb || {};
    this.spm = fs / 1000;
    // مرشح تمرير منخفض (Hann-windowed sinc) بعد الخلط عند 1900Hz
    var N = 2 * Math.round(0.75 * fs / 1000) + 1;
    var M = (N - 1) / 2, fc = 1700 / fs, h = new Float64Array(N), sum = 0, k;
    for (k = 0; k < N; k++) {
      var x = k - M;
      var s = x === 0 ? 2 * fc : Math.sin(TWO_PI * fc * x) / (Math.PI * x);
      var w = 0.5 + 0.5 * Math.cos(Math.PI * x / (M + 1));
      h[k] = s * w;
      sum += h[k];
    }
    for (k = 0; k < N; k++) h[k] /= sum;
    this.N = N;
    this.h = h;
    this.bre = new Float64Array(2 * N);
    this.bim = new Float64Array(2 * N);
    this.pos = 0;
    this.ph = 0;
    this.dph = TWO_PI * 1900 / fs;
    this.pr = 0;
    this.pq = 0;
    // مخزن التردد اللحظي
    this.cap = Math.max(65536, Math.floor(fs * 2));
    this.f = new Float32Array(this.cap);
    this.n = 0;
    this.base = 0;
    // متوسطات 1ms لاكتشاف VIS
    this.fm = [];
    this.fmBase = 0;
    this.msNext = 0;
    this.skipMs = -1;
    this.state = 0;
    this.calA = 1;
    this.calS = 1200;
    this.previewEvery = 0;
  }

  SstvDecoder.prototype.status = function (m) {
    if (this.cb.status) this.cb.status(m);
  };

  SstvDecoder.prototype.push = function (x) {
    var N = this.N, h = this.h, bre = this.bre, bim = this.bim, pos = this.pos;
    var ph = this.ph, dph = this.dph, pr = this.pr, pq = this.pq, k2 = this.fs / TWO_PI;
    var f = this.f, n = this.n;
    for (var i = 0; i < x.length; i++) {
      var v = x[i];
      var c = Math.cos(ph), s = Math.sin(ph);
      ph += dph;
      if (ph > TWO_PI) ph -= TWO_PI;
      var re = v * c, im = -v * s;
      bre[pos] = re; bre[pos + N] = re;
      bim[pos] = im; bim[pos + N] = im;
      var yr = 0, yi = 0, o = pos + 1;
      for (var j = 0; j < N; j++) {
        var hj = h[j];
        yr += hj * bre[o + j];
        yi += hj * bim[o + j];
      }
      pos++;
      if (pos >= N) pos = 0;
      var d = Math.atan2(yi * pr - yr * pq, yr * pr + yi * pq);
      pr = yr; pq = yi;
      var fr = 1900 + d * k2;
      if (fr < 900) fr = 900; else if (fr > 2800) fr = 2800;
      if (n >= this.cap) {
        this.cap *= 2;
        var nf = new Float32Array(this.cap);
        nf.set(f.subarray(0, n));
        f = nf;
        this.f = nf;
      }
      f[n++] = fr;
    }
    this.pos = pos; this.ph = ph; this.pr = pr; this.pq = pq; this.n = n;
    this._run();
  };

  SstvDecoder.prototype._trim = function (newBase) {
    newBase = Math.floor(newBase);
    if (newBase <= this.base) return;
    var shift = newBase - this.base;
    if (shift >= this.n) {
      this.n = 0;
      this.base = newBase;
      return;
    }
    // نقلّ فقط عندما يستحق ذلك
    if (shift < this.cap / 8 && this.n < this.cap * 0.9) return;
    this.f.copyWithin(0, shift, this.n);
    this.n -= shift;
    this.base = newBase;
  };

  SstvDecoder.prototype._run = function () {
    for (;;) {
      var more = this.state === 0 ? this._idleStep() : this._imageStep();
      if (!more) break;
    }
  };

  // ───────── الانتظار واكتشاف VIS ─────────
  SstvDecoder.prototype._idleStep = function () {
    var spm = this.spm;
    for (;;) {
      var a = Math.round(this.msNext * spm), b = Math.round((this.msNext + 1) * spm);
      if (b > this.base + this.n) break;
      if (a < this.base) { this.msNext++; continue; }
      var s = 0;
      for (var i = a; i < b; i++) s += this.f[i - this.base];
      this.fm.push(s / (b - a));
      this.msNext++;
      if (this._visCheck()) return true;
    }
    if (this.fm.length > 6000) {
      this.fm.splice(0, 3000);
      this.fmBase += 3000;
    }
    this._trim(Math.round(this.msNext * spm) - 4);
    return false;
  };

  function isS(v) { return v > 1030 && v < 1370; }

  SstvDecoder.prototype._visCheck = function () {
    var fm = this.fm, L = fm.length, i = L - 1 - 305, k, j;
    if (i < 130) return false;
    var absS = this.fmBase + i;
    if (absS < this.skipMs) return false;
    if (!isS(fm[i]) || !isS(fm[i + 1])) return false;
    var c = 0;
    for (k = i - 6; k < i; k++) if (isS(fm[k])) c++;
    if (c > 1) return false;
    c = 0;
    for (k = i; k < i + 28; k++) if (isS(fm[k])) c++;
    if (c < 25) return false;
    var lc = 0, ls = 0;
    for (k = i - 120; k < i - 8; k++) {
      var v = fm[k];
      if (v > 1700 && v < 2100) { lc++; ls += v; }
    }
    if (lc < 95) return false;
    var leader = ls / lc, sm = 0;
    for (k = i + 3; k < i + 27; k++) sm += fm[k];
    sm /= 24;
    if (sm < 1050 || sm > 1350) return false;
    var bits = [], m, st;
    for (k = 0; k < 8; k++) {
      st = i + 30 + 30 * k + 6;
      m = 0;
      for (j = 0; j < 18; j++) m += fm[st + j];
      m /= 18;
      if (Math.abs(m - sm) < 40 || Math.abs(m - sm) > 190) return false;
      bits.push(m < sm ? 1 : 0);
    }
    st = i + 270 + 6;
    m = 0;
    for (j = 0; j < 18; j++) m += fm[st + j];
    m /= 18;
    if (Math.abs(m - sm) > 70) return false;
    var ones = 0, vis = 0;
    for (k = 0; k < 8; k++) ones += bits[k];
    if (ones % 2) return false;
    for (k = 0; k < 7; k++) vis |= bits[k] << k;
    // معايرة بسيطة من نغمة التمهيد (1900) ونغمة البدء (1200)
    var a = 700 / (leader - sm);
    if (a > 0.85 && a < 1.2) {
      this.calA = a;
      this.calS = sm;
    } else {
      this.calA = 1;
      this.calS = 1200;
    }
    var mode = MODES[vis];
    if (!mode) {
      this.status('تم اكتشاف إشارة SSTV بنمط غير مدعوم (VIS ' + vis + ')');
      this.skipMs = absS + 300;
      return false;
    }
    this._start(mode, (absS + 300) * this.spm);
    return true;
  };

  SstvDecoder.prototype._start = function (mode, visEnd) {
    this.mode = mode;
    this.state = 1;
    this.lineIdx = 0;
    this.rows = 0;
    this.miss = 0;
    this.found = 0;
    this.drift = 0;
    this.prevT = null;
    this.rgb = new Uint8ClampedArray(mode.w * mode.h * 4);
    for (var i = 3; i < this.rgb.length; i += 4) this.rgb[i] = 255;
    this.expT = visEnd;
    if (mode.kind === 'sco') {
      var seg = mode.w * mode.px;
      this.expT = visEnd + 1.5 * this.spm + 2 * seg * this.spm + 1.5 * this.spm;
    }
    this.yPrev = null;
    this.cPrev = null;
    this.cPrevType = 0;
    this.fm = [];
    this.previewEvery = mode.kind === 'pd' ? 12 : 24;
    this.status('بدأ استقبال صورة SSTV بنمط ' + mode.name);
  };

  SstvDecoder.prototype.info = function (complete) {
    return { mode: this.mode.name, w: this.mode.w, h: this.mode.h, rows: this.rows, rgba: this.rgb, complete: !!complete };
  };

  SstvDecoder.prototype._finish = function (reason, complete) {
    if (this.state !== 1) return;
    this._flushPending();
    var rows = this.rows;
    var minRows = Math.min(8, this.mode.h);
    if (rows >= minRows && this.cb.done) this.cb.done(this.info(complete), reason || '', !!complete);
    else this.status('انتهى الاستقبال بدون صورة كافية');
    this.state = 0;
    var spm = this.spm;
    var ms = Math.ceil(Math.max(this.expT, this.base) / spm);
    this.fm = [];
    this.fmBase = ms;
    this.msNext = ms;
    this.skipMs = -1;
    this.rgb = null;
  };

  SstvDecoder.prototype.finish = function () {
    if (this.state === 1) {
      this.flushing = true;
      this._run();
      this.flushing = false;
    }
    if (this.state === 1) this._finish('انتهى', false);
  };

  // ───────── استقبال الصورة ─────────
  SstvDecoder.prototype._imageStep = function () {
    var m = this.mode, spm = this.spm, endAbs = this.base + this.n;
    var W = (this.miss > 0 || this.lineIdx === 0) ? 16 : 6;
    if (m.kind === 'sco' && this.lineIdx === 0) W = 30;
    var seg = m.px ? m.w * m.px : 0;
    var after = m.kind === 'sco' ? 10.5 + seg : m.line;
    var before = m.kind === 'sco' ? 2 * seg + 4 : 0;
    var T = this.expT;
    if (T + (after + (this.flushing ? 0 : W + 6)) * spm > endAbs) return false;
    var syncSamp = m.sync * spm;
    var found = this._findSyncEnd(T + syncSamp, W * spm, syncSamp);
    if (found !== null) {
      T = found - syncSamp;
      this.miss = 0;
      this.found++;
      if (this.prevT !== null) {
        var d = (T - this.prevT) / (m.line * spm) - 1;
        if (Math.abs(d) < 0.01) this.drift = 0.8 * this.drift + 0.2 * d;
      }
      this.prevT = T;
    } else {
      this.miss++;
      this.prevT = null;
    }
    if (this.lineIdx === 6 && this.found < 3) {
      this.status('إشارة ضعيفة جدًا — أُلغي الاستقبال');
      this.rows = 0;
      this._finish('ضعيف', false);
      return true;
    }
    if (this.miss >= Math.max(8, Math.ceil(12000 / m.line))) {
      this._finish('انقطعت الإشارة', false);
      return true;
    }
    this._decodeLine(m, T);
    this.lineIdx++;
    this.expT = T + m.line * spm * (1 + this.drift);
    if (this.cb.preview && this.lineIdx % this.previewEvery === 0 && this.rows > 0) {
      this.cb.preview(this.info(false));
    }
    if (this.lineIdx >= m.lines) {
      this._finish(null, true);
      return true;
    }
    this._trim(this.expT - (before + W + 10) * spm);
    return true;
  };

  /** يبحث عن نهاية نبضة التزامن (1200Hz → أعلى) بالقرب من المتوقَّع؛ يعيد موضعًا كسريًا أو null. */
  SstvDecoder.prototype._findSyncEnd = function (expEnd, Wsamp, syncSamp) {
    var f = this.f, base = this.base, n = this.n;
    var lo = Math.floor(expEnd - Wsamp), hi = Math.ceil(expEnd + Wsamp);
    var minRun = Math.max(6, Math.round(0.6 * syncSamp));
    var best = null, bestD = 1e18;
    for (var j = lo; j <= hi; j++) {
      var i = j - base;
      if (i - minRun < 1 || i + 5 >= n) continue;
      if (f[i] >= 1350 && f[i - 1] < 1350) {
        var cnt = 0, q;
        for (q = i - minRun; q < i; q++) if (f[q] < 1350) cnt++;
        if (cnt < minRun * 0.9) continue;
        var up = 0;
        for (q = i; q < i + 5; q++) if (f[q] >= 1350) up++;
        if (up < 4) continue;
        var fr = (i - 1) + (1350 - f[i - 1]) / (f[i] - f[i - 1]);
        var dd = Math.abs(fr + base - expEnd);
        if (dd < bestD) { bestD = dd; best = fr + base; }
      }
    }
    return best;
  };

  /** متوسط التردد اللحظي في النافذة [a,b) (بالعينات المطلقة) مع إهمال الحواف. */
  SstvDecoder.prototype._avg = function (a, b) {
    var w = b - a;
    var lo = Math.round(a + 0.2 * w), hi = Math.round(b - 0.2 * w);
    if (hi <= lo) { lo = Math.round((a + b) / 2); hi = lo; }
    lo -= this.base; hi -= this.base;
    if (lo < 0 || hi >= this.n) return 1500;
    var s = 0;
    for (var i = lo; i <= hi; i++) s += this.f[i];
    return s / (hi - lo + 1);
  };

  SstvDecoder.prototype._val = function (f) {
    var f2 = 1200 + (f - this.calS) * this.calA;
    var v = (f2 - 1500) * 0.31875;
    return v < 0 ? 0 : (v > 255 ? 255 : v);
  };

  /** يقرأ مقطعًا بعرض w بكسل يبدأ عند start (عينات) إلى مصفوفة out بعدد outW (تكرار إن لزم). */
  SstvDecoder.prototype._scan = function (start, pxMs, w, out) {
    var pxS = pxMs * this.spm;
    for (var x = 0; x < w; x++) {
      var a = start + x * pxS;
      out[x] = this._val(this._avg(a, a + pxS));
    }
  };

  function clamp8(v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

  SstvDecoder.prototype._setPx = function (row, x, r, g, b) {
    var o = (row * this.mode.w + x) * 4;
    this.rgb[o] = clamp8(r);
    this.rgb[o + 1] = clamp8(g);
    this.rgb[o + 2] = clamp8(b);
  };

  SstvDecoder.prototype._putYC = function (row, Y, Cr, Cb, cw) {
    var w = this.mode.w, ratio = cw === w ? 1 : 2;
    for (var x = 0; x < w; x++) {
      var y = Y[x], cr = Cr[(x / ratio) | 0] - 128, cb = Cb[(x / ratio) | 0] - 128;
      this._setPx(row, x, y + 1.402 * cr, y - 0.344136 * cb - 0.714136 * cr, y + 1.772 * cb);
    }
    if (row + 1 > this.rows) this.rows = row + 1;
  };

  SstvDecoder.prototype._decodeLine = function (m, T) {
    var spm = this.spm, w = m.w, x, row = this.lineIdx;
    if (!this._buf || this._buf.w !== w) {
      this._buf = { w: w, a: new Float32Array(w), b: new Float32Array(w), c: new Float32Array(w), d: new Float32Array(w) };
    }
    var A = this._buf.a, B = this._buf.b, C = this._buf.c, D = this._buf.d;
    if (m.kind === 'pd') {
      var s0 = T + 22.08 * spm, sg = m.seg * spm;
      this._scan(s0, m.px, w, A);              // Y (الصف الزوجي)
      this._scan(s0 + sg, m.px, w, B);         // R-Y
      this._scan(s0 + 2 * sg, m.px, w, C);     // B-Y
      this._scan(s0 + 3 * sg, m.px, w, D);     // Y (الصف الفردي)
      this._putYC(2 * row, A, B, C, w);
      if (2 * row + 1 < m.h) this._putYC(2 * row + 1, D, B, C, w);
    } else if (m.kind === 'mar') {
      var seg = m.w * m.px * spm, sep = 0.572 * spm;
      var g0 = T + (m.sync + 0.572) * spm;
      var b0 = g0 + seg + sep, r0 = b0 + seg + sep;
      this._scan(g0, m.px, w, A);
      this._scan(b0, m.px, w, B);
      this._scan(r0, m.px, w, C);
      for (x = 0; x < w; x++) this._setPx(row, x, C[x], A[x], B[x]);
      if (row + 1 > this.rows) this.rows = row + 1;
    } else if (m.kind === 'sco') {
      var sc = m.w * m.px * spm;
      var bS = T - sc, gS = bS - 1.5 * spm - sc, rS = T + 10.5 * spm;
      this._scan(gS, m.px, w, A);
      this._scan(bS, m.px, w, B);
      this._scan(rS, m.px, w, C);
      for (x = 0; x < w; x++) this._setPx(row, x, C[x], A[x], B[x]);
      if (row + 1 > this.rows) this.rows = row + 1;
    } else if (m.kind === 'r72') {
      var yS = T + 12 * spm;
      this._scan(yS, 138 / 320, w, A);
      var cw = 160;
      this._scan(T + 156 * spm, 69 / 160, cw, B);   // R-Y
      this._scan(T + 231 * spm, 69 / 160, cw, C);   // B-Y
      this._putYC(row, A, B, C, cw);
    } else { // Robot36: سطر Y + سطر لوني واحد (R-Y أو B-Y بالتناوب)
      this._scan(T + 12 * spm, 88 / 320, w, A);
      var cs = new Float32Array(160);
      this._scan(T + 106 * spm, 44 / 160, 160, cs);
      // نغمة الفاصل: 1500 ← R-Y ، 2300 ← B-Y
      var sepF = this._avg(T + 100 * spm, T + 104 * spm);
      var isBy = sepF > 1900;
      var type = isBy ? 2 : 1;
      if (this.yPrev && this.cPrevType && this.cPrevType !== type) {
        var cr = type === 1 ? cs : this.cPrev, cb = type === 2 ? cs : this.cPrev;
        this._putYC(row - 1, this.yPrev, cr, cb, 160);
        this._putYC(row, A, cr, cb, 160);
        this.yPrev = null;
        this.cPrev = null;
        this.cPrevType = 0;
      } else {
        this.yPrev = new Float32Array(A);
        this.cPrev = cs;
        this.cPrevType = type;
        this.pendRow = row;
      }
    }
  };

  /** Robot36: صفّ وحيد معلّق في النهاية (بدون زوجه) */
  SstvDecoder.prototype._flushPending = function () {
    if (this.mode && this.mode.kind === 'r36' && this.yPrev && this.cPrev) {
      var gray = new Float32Array(160);
      for (var i = 0; i < 160; i++) gray[i] = 128;
      var t = this.cPrevType;
      this._putYC(this.pendRow, this.yPrev, t === 1 ? this.cPrev : gray, t === 2 ? this.cPrev : gray, 160);
      this.yPrev = null;
    }
  };

  var api = { SstvDecoder: SstvDecoder, MODES: MODES };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.SstvDecoder = SstvDecoder;
  root.SSTV_MODES = MODES;
})(typeof window !== 'undefined' ? window : globalThis);

/* وصلة فك SSTV بالصفحة: تحويل الصورة إلى JPEG/PNG وإرسالها إلى التطبيق عبر القناة Rec */
(function () {
  if (window.__sstv) return;
  var S = { dec: null, fs: 0, off: null, offFs: 0 };

  function post(t, s) { try { Rec.postMessage(t + s); } catch (e) {} }
  function cfg() { return window.__issCfg || {}; }

  function enhance(a, w, rows) {
    var hist = new Uint32Array(256), n = w * rows, i, o;
    for (i = 0; i < n; i++) { o = i * 4; hist[(0.299 * a[o] + 0.587 * a[o + 1] + 0.114 * a[o + 2]) | 0]++; }
    var lo = 0, hi = 255, acc = 0, t1 = n * 0.005, t2 = n * 0.995;
    for (i = 0; i < 256; i++) { acc += hist[i]; if (acc >= t1) { lo = i; break; } }
    acc = 0;
    for (i = 0; i < 256; i++) { acc += hist[i]; if (acc >= t2) { hi = i; break; } }
    if (hi - lo < 40 || hi - lo > 235) return;
    var k = 255 / (hi - lo);
    for (i = 0; i < n; i++) {
      o = i * 4;
      a[o] = (a[o] - lo) * k; a[o + 1] = (a[o + 1] - lo) * k; a[o + 2] = (a[o + 2] - lo) * k;
    }
  }

  function b64img(info, type, q) {
    var w = info.w, rows = info.rows;
    var a = info.rgba.slice(0, w * rows * 4);
    if (cfg().enh !== 0) enhance(a, w, rows);
    var cv = document.createElement('canvas');
    cv.width = w; cv.height = rows;
    var cx = cv.getContext('2d');
    var id = cx.createImageData(w, rows);
    id.data.set(a);
    cx.putImageData(id, 0, 0);
    var u = cv.toDataURL(type, q);
    return u.substring(u.indexOf(',') + 1);
  }

  function H() {
    return {
      status: function (m) { post('M', m); },
      preview: function (i) { post('P', i.mode + '|' + i.rows + '|' + i.h + '|' + b64img(i, 'image/jpeg', 0.7)); },
      done: function (i, r, c) { post('I', i.mode + '|' + i.rows + '|' + i.h + '|' + (c ? 1 : 0) + '|' + b64img(i, 'image/png')); }
    };
  }

  window.__sstv = {
    push: function (d, fs) {
      if (!S.dec || S.fs !== fs) {
        if (S.dec) S.dec.finish();
        S.dec = new SstvDecoder(fs, H());
        S.fs = fs;
      }
      S.dec.push(d);
    },
    finish: function () { if (S.dec) S.dec.finish(); },
    feedB64: function (b, fs) {
      var bin = atob(b), n = bin.length >> 1, out = new Float32Array(n), i, v;
      for (i = 0; i < n; i++) {
        v = (bin.charCodeAt(2 * i + 1) << 8) | bin.charCodeAt(2 * i);
        if (v & 0x8000) v -= 65536;
        out[i] = v / 32768;
      }
      if (!S.off || S.offFs !== fs) { S.off = new SstvDecoder(fs, H()); S.offFs = fs; }
      S.off.push(out);
    },
    end: function () { if (S.off) S.off.finish(); post('E', ''); }
  };
})();

''';

const autoStartJs = r'''
(function(){
var ws=WS_FLAG;
function go(){
  var e=document.getElementById('openwebrx-big-grey');if(e){e.click();return;}
  if(ws)return;
  var c=document.querySelectorAll('button,div,span,a');
  for(var i=0;i<c.length;i++){
    var t=(c[i].innerText||'').trim().toLowerCase();
    if(c[i].children.length<3&&t.length<40&&/^(start|click to start|tap to start|start openwebrx)/.test(t)){c[i].click();return;}
  }
}
setTimeout(go,2500);setTimeout(go,6000);setTimeout(go,12000);
})();

''';

