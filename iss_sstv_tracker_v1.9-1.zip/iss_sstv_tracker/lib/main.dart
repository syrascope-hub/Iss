import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tzd;
import 'package:timezone/timezone.dart' as tz;
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

import 'js_assets.dart';
import 'models.dart';
import 'orbit.dart';
import 'painters.dart';

const appId = 'com.astro.iss_sstv_tracker';
const cream = Color(0xFFF5EFDC), ink = Color(0xFF111111);

final fln = FlutterLocalNotificationsPlugin();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tzd.initializeTimeZones();
  await fln.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
  await fln.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
  runApp(MaterialApp(
    title: 'ISS SSTV',
    debugShowCheckedModeBanner: false,
    themeMode: ThemeMode.system, // يتبع نظام الجهاز
    theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: ink, surface: cream),
        navigationBarTheme: const NavigationBarThemeData(backgroundColor: cream),
        appBarTheme: const AppBarTheme(backgroundColor: ink, foregroundColor: cream)),
    darkTheme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: ink,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrange, brightness: Brightness.dark, surface: ink),
        navigationBarTheme: const NavigationBarThemeData(backgroundColor: Color(0xFF1C1C1C)),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF1C1C1C), foregroundColor: cream)),
    builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
    home: const Home(),
  ));
}

class Best {
  final St s;
  final double el;
  final String note;
  Best(this.s, this.el, this.note);
}

/// عارض صورة SSTV بملء الشاشة مع تكبير ومشاركة وحذف.
class ImgViewer extends StatelessWidget {
  final File file;
  final Future<void> Function() onDelete;
  const ImgViewer({super.key, required this.file, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(file.path.split('/').last, style: const TextStyle(fontSize: 13)),
        actions: [
          IconButton(icon: const Icon(Icons.share), onPressed: () => Share.shareXFiles([XFile(file.path)])),
          IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                await onDelete();
                if (context.mounted) Navigator.of(context).pop();
              }),
        ],
      ),
      body: InteractiveViewer(maxScale: 6, child: Center(child: Image.file(file))),
    );
  }
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _S();
}

class _S extends State<Home> {
  int tab = 0;
  final orbs = <int, Orb>{};
  Orb? get o => orbs[sat.norad];
  Sat sat = builtinSats[0];
  Fq fq = builtinSats[0].fqs[1];
  List<Sat> customSats = [];
  List<Sat> get sats => [...builtinSats, ...customSats];
  final freqCtl = TextEditingController();
  St sel = stations[0];
  List<Pass> ps = [];
  bool listening = false, recording = false, showPage = false;
  String err = '';
  double? cmd; // التردد المضبوط يدويًا (Hz)، null = التردد الاسمي
  double get curHz => cmd ?? fq.hz;
  final log = <String>[];
  late final WebViewController wc; // صفحة المحطة
  late final WebViewController dc; // فك SSTV للتسجيلات (صفحة فارغة مخفية)
  SharedPreferences? sp;
  Timer? tk;

  // الإعدادات
  bool autoPass = false, autoRec = true, sstvOn = true, enh = true, autoBest = false, screenOff = false, autoRecon = true;
  double minPassEl = 15, vol = 1.0, sq = 0.0;

  // التسجيل
  IOSink? _pcmSink;
  File? _pcmFile;
  int _recBytes = 0, _recRate = 48000;
  DateTime? _recStart;
  String _recName = '';
  String audioState = '';
  List<File> recs = [];
  List<File> imgs = [];

  // SSTV مباشر
  Uint8List? liveImg;
  String liveMode = '', sstvStatus = '';
  int liveRows = 0, liveH = 0;

  // فك التسجيلات
  bool decBusy = false;
  double decProg = 0;
  String decMsg = '';
  int _decImgs = 0;
  Completer<void>? _dcLoaded, _decDone;

  // مرور تلقائي وإعادة اتصال
  bool _autoStarted = false, _fgOn = false;
  double? _declinedAos;
  double _psT = 0;
  int _badSecs = 0, _deadSecs = 0, _reconTries = 0;
  Best? best;

  // كاش مسار الخريطة (يُعاد حسابه كل 30 ثانية فقط)
  double _trackT = 0;
  List<List<LatLng>> _past = [], _fut = [];
  LatLng mapCenter = LatLng(45, 10);
  double mapZoom = 2.5;

  double get now => DateTime.now().millisecondsSinceEpoch / 1000;
  V get ob => obsV(sel.lat, sel.lon);

  void _js(WebViewController c, String code) {
    c.runJavaScript(code).catchError((_) {});
  }

  String get _cfgJs =>
      'window.__issCfg=Object.assign(window.__issCfg||{},{vol:$vol,sq:$sq,sstv:${sstvOn ? 1 : 0},enh:${enh ? 1 : 0}});';

  void _inject() {
    _js(wc, _cfgJs);
    _js(wc, hookJs);
    _js(wc, sstvJs);
  }

  void _pushCfg() {
    _js(wc, '$_cfgJs;window.__issRec&&window.__issRec.apply&&window.__issRec.apply();');
  }

  @override
  void initState() {
    super.initState();
    wc = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel('Rec', onMessageReceived: (m) => _onRec(m.message));
    dc = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel('Rec', onMessageReceived: (m) => _onDec(m.message));
    final p = wc.platform;
    if (p is AndroidWebViewController) p.setMediaPlaybackRequiresUserGesture(false);
    wc.setNavigationDelegate(NavigationDelegate(
      onPageStarted: (_) => _inject(),
      onPageFinished: (_) {
        _inject();
        _js(wc, autoStartJs.replaceFirst('WS_FLAG', sel.ws.toString()));
      },
      onWebResourceError: (e) {
        if (listening && autoRecon && e.isForMainFrame == true) _scheduleRecon();
      },
    ));
    dc.setNavigationDelegate(NavigationDelegate(onPageFinished: (_) {
      final c = _dcLoaded;
      if (c != null && !c.isCompleted) c.complete();
    }));
    _init();
    _check();
    _loadRecs();
    _loadImgs();
    int i = 0;
    tk = Timer.periodic(const Duration(seconds: 1), (_) {
      i++;
      if (listening && i % 3 == 0) _pollAudio();
      if (listening) _reconTick();
      if (autoPass) _autoTick();
      if (o != null && now - _psT > 1800) refresh();
      if (mounted) setState(() {});
    });
  }

  Future<void> _pollAudio() async {
    try {
      final r = await wc.runJavaScriptReturningResult('window.__issRec?window.__issRec.state():"nohook"');
      audioState = r.toString().replaceAll('"', '');
    } catch (_) {}
  }

  @override
  void dispose() {
    tk?.cancel();
    _pcmSink?.close();
    freqCtl.dispose();
    WakelockPlus.disable();
    super.dispose();
  }

  // ───────────── المحطات وفحصها ─────────────

  void _check() {
    for (final s in stations) {
      http.get(Uri.parse(s.u)).timeout(const Duration(seconds: 6)).then((r) {
        if (mounted) setState(() => s.ok = r.statusCode < 400);
      }).catchError((_) {
        if (mounted) setState(() => s.ok = false);
      });
    }
  }

  /// أفضل محطة لمرور معيّن: أعلى ارتفاع للقمر فوق المحطة، مع تفضيل ما يغطي التردد.
  Best? _bestStation(Pass? ref) {
    final orb = o;
    if (orb == null) return null;
    final t0 = now;
    Best? b;
    double bs = -1e9;
    for (final s in stations) {
      if (s.ok == false) continue;
      final cv = s.coverage(fq.hz);
      if (cv.s == 'n') continue;
      final l = orb.passes(s.lat, s.lon, t0, hours: 12);
      Pass? pick;
      for (final p in l) {
        if (p.los <= t0) continue;
        if (ref == null) {
          pick = p;
          break;
        }
        if (p.aos < ref.los && p.los > ref.aos) {
          pick = p;
          break;
        }
      }
      if (pick == null) continue;
      final score = pick.maxEl + (cv.s == 'y' ? 6 : 0) - (s.unv ? 3 : 0) - (s.approx ? 1 : 0);
      if (score > bs) {
        bs = score;
        b = Best(s, pick.maxEl, cv.s == 'y' ? 'تغطي التردد' : 'التغطية غير معروفة');
      }
    }
    return b;
  }

  // ───────────── الإعدادات والنسخ الاحتياطي ─────────────

  Future<void> _init() async {
    sp = await SharedPreferences.getInstance();
    final i = sp!.getInt('sel') ?? 0;
    if (i >= 0 && i < stations.length) sel = stations[i];
    _loadCustom();
    autoPass = sp!.getBool('autoPass') ?? false;
    autoRec = sp!.getBool('autoRec') ?? true;
    sstvOn = sp!.getBool('sstvOn') ?? true;
    enh = sp!.getBool('enh') ?? true;
    autoBest = sp!.getBool('autoBest') ?? false;
    screenOff = sp!.getBool('screenOff') ?? false;
    autoRecon = sp!.getBool('autoRecon') ?? true;
    minPassEl = (sp!.getDouble('minPassEl') ?? 15).clamp(5.0, 60.0).toDouble();
    vol = (sp!.getDouble('vol') ?? 1.0).clamp(0.0, 2.0).toDouble();
    sq = (sp!.getDouble('sq') ?? 0.0).clamp(0.0, 0.05).toDouble();
    final sn = sp!.getInt('satN');
    if (sn != null) {
      final m = sats.where((s) => s.norad == sn);
      if (m.isNotEmpty) {
        sat = m.first;
        fq = sat.fqs.first;
      }
    }
    final fh = sp!.getDouble('fqHz');
    if (fh != null) {
      final m = sat.fqs.where((q) => q.hz == fh);
      fq = m.isNotEmpty ? m.first : Fq('${(fh / 1e6).toStringAsFixed(4)} مخصص', fh, sat.fqs.first.mod);
    }
    if (mounted) setState(() {});
    _fgSync();
    await loadTle();
  }

  Future<void> _saveSettings() async {
    final s = sp;
    if (s == null) return;
    await s.setBool('autoPass', autoPass);
    await s.setBool('autoRec', autoRec);
    await s.setBool('sstvOn', sstvOn);
    await s.setBool('enh', enh);
    await s.setBool('autoBest', autoBest);
    await s.setBool('screenOff', screenOff);
    await s.setBool('autoRecon', autoRecon);
    await s.setDouble('minPassEl', minPassEl);
    await s.setDouble('vol', vol);
    await s.setDouble('sq', sq);
  }

  Future<void> _saveCustom() async {
    await sp?.setString(
        'custSats',
        jsonEncode([
          for (final s in customSats) {'n': s.name, 'i': s.norad, 'f': [for (final q in s.fqs) q.toJson()]}
        ]));
  }

  void _loadCustom() {
    final raw = sp?.getString('custSats');
    if (raw == null) return;
    try {
      final l = jsonDecode(raw) as List;
      customSats = [
        for (final e in l)
          Sat(e['n'] as String, e['i'] as int,
              [for (final q in e['f'] as List) Fq.fromJson(Map<String, dynamic>.from(q as Map))],
              custom: true)
      ];
    } catch (_) {}
  }

  String _exportJson() => jsonEncode({
        'v': 1,
        'station': sel.u,
        'sat': sat.norad,
        'fq': fq.hz,
        'custSats': [
          for (final s in customSats) {'n': s.name, 'i': s.norad, 'f': [for (final q in s.fqs) q.toJson()]}
        ],
        'autoPass': autoPass,
        'autoRec': autoRec,
        'sstvOn': sstvOn,
        'enh': enh,
        'autoBest': autoBest,
        'screenOff': screenOff,
        'autoRecon': autoRecon,
        'minPassEl': minPassEl,
        'vol': vol,
        'sq': sq,
      });

  Future<bool> _importJson(String txt) async {
    try {
      final m = jsonDecode(txt) as Map<String, dynamic>;
      if (m['custSats'] is List) {
        customSats = [
          for (final e in m['custSats'] as List)
            Sat(e['n'] as String, e['i'] as int,
                [for (final q in e['f'] as List) Fq.fromJson(Map<String, dynamic>.from(q as Map))],
                custom: true)
        ];
        await _saveCustom();
      }
      bool b(String k, bool d) => m[k] is bool ? m[k] as bool : d;
      double dd(String k, double d) => m[k] is num ? (m[k] as num).toDouble() : d;
      autoPass = b('autoPass', autoPass);
      autoRec = b('autoRec', autoRec);
      sstvOn = b('sstvOn', sstvOn);
      enh = b('enh', enh);
      autoBest = b('autoBest', autoBest);
      screenOff = b('screenOff', screenOff);
      autoRecon = b('autoRecon', autoRecon);
      minPassEl = dd('minPassEl', minPassEl).clamp(5.0, 60.0).toDouble();
      vol = dd('vol', vol).clamp(0.0, 2.0).toDouble();
      sq = dd('sq', sq).clamp(0.0, 0.05).toDouble();
      await _saveSettings();
      final su = m['station'];
      if (su is String) {
        final i = stations.indexWhere((s) => s.u == su);
        if (i >= 0) {
          sel = stations[i];
          await sp?.setInt('sel', i);
        }
      }
      final sn = m['sat'];
      if (sn is int) {
        final f = sats.where((s) => s.norad == sn);
        if (f.isNotEmpty) {
          sat = f.first;
          fq = sat.fqs.first;
          final h = m['fq'];
          if (h is num) {
            final q = sat.fqs.where((x) => x.hz == h.toDouble());
            fq = q.isNotEmpty ? q.first : Fq('${(h / 1e6).toStringAsFixed(4)} مخصص', h.toDouble(), sat.fqs.first.mod);
          }
          await sp?.setInt('satN', sat.norad);
          await sp?.setDouble('fqHz', fq.hz);
        }
      }
      _pushCfg();
      _fgSync();
      if (mounted) setState(() {});
      await loadTle();
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> _importDialog() async {
    final ctl = TextEditingController();
    final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
              title: const Text('استيراد الإعدادات'),
              content: TextField(
                  controller: ctl, maxLines: 6, decoration: const InputDecoration(hintText: 'الصق النص المنسوخ هنا')),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
                FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('استيراد')),
              ],
            ));
    if (ok != true) return;
    final done = await _importJson(ctl.text.trim());
    _snack(done ? 'تم استيراد الإعدادات' : 'النص غير صالح');
  }

  void _openSettings() {
    showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        builder: (ctx) => StatefulBuilder(builder: (ctx, setS) {
              void upd(VoidCallback f) {
                setS(f);
                setState(() {});
                _saveSettings();
                _pushCfg();
                _fgSync();
              }

              return Directionality(
                  textDirection: TextDirection.rtl,
                  child: SafeArea(
                      child: ListView(padding: const EdgeInsets.all(12), shrinkWrap: true, children: [
                    const Text('الإعدادات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    SwitchListTile(
                        title: const Text('استماع تلقائي عند كل مرور'),
                        subtitle: const Text('يبدأ قبل المرور بـ 45 ثانية ويتوقف بعده. يحتاج بقاء التطبيق يعمل (خدمة خلفية).'),
                        value: autoPass,
                        onChanged: (v) => upd(() => autoPass = v)),
                    ListTile(
                        title: Text('أقل ارتفاع للمرور التلقائي: ${minPassEl.round()}°'),
                        subtitle: Slider(
                            value: minPassEl,
                            min: 5,
                            max: 60,
                            divisions: 11,
                            onChanged: (v) => upd(() => minPassEl = v))),
                    SwitchListTile(
                        title: const Text('تسجيل الصوت تلقائيًا'),
                        value: autoRec,
                        onChanged: (v) => upd(() => autoRec = v)),
                    SwitchListTile(
                        title: const Text('اختيار أفضل محطة تلقائيًا'),
                        subtitle: const Text('عند بدء مرور تلقائي يختار المحطة التي يعلو فوقها القمر أكثر.'),
                        value: autoBest,
                        onChanged: (v) => upd(() => autoBest = v)),
                    SwitchListTile(
                        title: const Text('فك صور SSTV تلقائيًا أثناء الاستماع'),
                        value: sstvOn,
                        onChanged: (v) => upd(() => sstvOn = v)),
                    SwitchListTile(
                        title: const Text('تحسين تباين الصورة'),
                        value: enh,
                        onChanged: (v) => upd(() => enh = v)),
                    SwitchListTile(
                        title: const Text('السماح بإطفاء الشاشة أثناء الاستماع'),
                        subtitle: const Text('تجريبي: يشغّل خدمة خلفية. إن توقف الصوت عند إطفاء الشاشة أوقف هذا الخيار، '
                            'واستثنِ التطبيق من توفير البطارية في إعدادات الجهاز.'),
                        value: screenOff,
                        onChanged: (v) => upd(() => screenOff = v)),
                    SwitchListTile(
                        title: const Text('إعادة الاتصال تلقائيًا عند انقطاع المحطة'),
                        value: autoRecon,
                        onChanged: (v) => upd(() => autoRecon = v)),
                    const Divider(),
                    ListTile(
                        leading: const Icon(Icons.copy),
                        title: const Text('نسخ الإعدادات (نسخة احتياطية)'),
                        subtitle: const Text('يشمل الأقمار المضافة والمحطة والتردد'),
                        onTap: () async {
                          await Clipboard.setData(ClipboardData(text: _exportJson()));
                          _snack('نُسخت الإعدادات — الصقها في ملاحظة للاحتفاظ بها');
                        }),
                    ListTile(
                        leading: const Icon(Icons.paste),
                        title: const Text('استيراد الإعدادات'),
                        onTap: () {
                          Navigator.pop(ctx);
                          _importDialog();
                        }),
                  ])));
            }));
  }

  // ───────────── الأقمار والترددات ─────────────

  Future<void> _pickSat(Sat s) async {
    if (recording) await stopRec();
    final was = listening;
    sat = s;
    fq = s.fqs.first;
    cmd = null;
    err = '';
    ps = [];
    sp?.setInt('satN', s.norad);
    sp?.setDouble('fqHz', fq.hz);
    setState(() {});
    await loadTle();
    if (was) listen();
  }

  void _pickFq(Fq q) {
    fq = q;
    cmd = null;
    sp?.setDouble('fqHz', q.hz);
    if (listening) listen();
    setState(() {});
    refresh();
  }

  void _applyCustomFreq() {
    final v = double.tryParse(freqCtl.text.trim().replaceAll(',', '.'));
    if (v == null || v < 30 || v > 3000) {
      _snack('تردد غير صالح (اكتبه بالميغاهرتز مثل 437.800)');
      return;
    }
    _pickFq(Fq('${v.toStringAsFixed(4)} مخصص', v * 1e6, fq.mod));
  }

  Future<void> _addSat() async {
    final nm = TextEditingController(), id = TextEditingController(), fr = TextEditingController();
    String mod = 'nfm';
    final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => StatefulBuilder(
            builder: (ctx, setD) => AlertDialog(
                  title: const Text('إضافة قمر'),
                  content: Column(mainAxisSize: MainAxisSize.min, children: [
                    TextField(controller: nm, decoration: const InputDecoration(labelText: 'الاسم')),
                    TextField(
                        controller: id,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'رقم NORAD')),
                    TextField(
                        controller: fr,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        decoration: const InputDecoration(labelText: 'تردد الهبوط MHz')),
                    DropdownButton<String>(
                        value: mod,
                        isExpanded: true,
                        items: const [
                          DropdownMenuItem(value: 'nfm', child: Text('FM')),
                          DropdownMenuItem(value: 'usb', child: Text('USB')),
                          DropdownMenuItem(value: 'lsb', child: Text('LSB')),
                        ],
                        onChanged: (v) => setD(() => mod = v ?? 'nfm')),
                  ]),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
                    FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إضافة')),
                  ],
                )));
    if (ok != true) return;
    final n = int.tryParse(id.text.trim());
    final mhz = double.tryParse(fr.text.trim().replaceAll(',', '.'));
    if (n == null || mhz == null || nm.text.trim().isEmpty) {
      _snack('بيانات غير صالحة');
      return;
    }
    final s = Sat(nm.text.trim(), n, [Fq('${mhz.toStringAsFixed(3)} MHz', mhz * 1e6, mod)], custom: true);
    customSats.add(s);
    await _saveCustom();
    await _pickSat(s);
  }

  Future<void> _delSat() async {
    if (!sat.custom) return;
    customSats.remove(sat);
    await _saveCustom();
    await _pickSat(builtinSats[0]);
  }

  String _wsMod(String m) => m == 'nfm' ? 'fm' : m;

  String wsState = '';

  /// محاولة ضبط تردد WebSDR دون إعادة تحميل الصفحة (تجريبي: يعتمد على دالة setfreq في الصفحة).
  Future<bool> _wsTune(double hz) async {
    try {
      final r = await wc.runJavaScriptReturningResult(
          '(function(){try{if(typeof setfreq==="function"){setfreq(${(hz / 1000).toStringAsFixed(3)});return "ok";}return "nofn";}catch(e){return "err";}})()');
      final v = r.toString().replaceAll('"', '');
      if (v != wsState) {
        wsState = v;
        log.insert(0, v == 'ok' ? 'WebSDR: الضبط الفوري يعمل' : 'WebSDR: لا ضبط فوري ($v) — سيُعاد تحميل الصفحة');
      }
      return v == 'ok';
    } catch (_) {
      return false;
    }
  }

  // ───────────── المدار والإشعارات ─────────────

  Orb? _parseTle(String body) {
    final l = body.split('\n').map((e) => e.trim()).toList();
    final a = l.where((e) => e.startsWith('1 ') && e.length >= 62).toList();
    final b = l.where((e) => e.startsWith('2 ') && e.length >= 63).toList();
    if (a.isEmpty || b.isEmpty) return null;
    return Orb(a.first, b.first);
  }

  /// يستخدم TLE المخزَّن إن كان أحدث من 6 ساعات، وإلا يجلب من CelesTrak،
  /// وعند الفشل يرجع للمخزَّن مهما كان عمره. (لكل قمر مفتاح خاص)
  Future<void> loadTle() async {
    final n = sat.norad;
    final key = 'tle_$n';
    final cached = sp?.getString(key);
    final age = DateTime.now().millisecondsSinceEpoch - (sp?.getInt('${key}_t') ?? 0);
    try {
      if (cached != null && age < 6 * 3600 * 1000) {
        final c = _parseTle(cached);
        if (c != null) {
          orbs[n] = c;
          err = '';
          await refresh();
          return;
        }
      }
      final r = await http
          .get(Uri.parse('https://celestrak.org/NORAD/elements/gp.php?CATNR=$n&FORMAT=tle'))
          .timeout(const Duration(seconds: 15));
      final fresh = _parseTle(r.body);
      if (fresh == null) throw Exception('رد غير صالح (تحقق من رقم NORAD)');
      await sp?.setString(key, r.body);
      await sp?.setInt('${key}_t', DateTime.now().millisecondsSinceEpoch);
      orbs[n] = fresh;
      err = '';
    } catch (e) {
      final c = cached == null ? null : _parseTle(cached);
      if (c != null) {
        orbs[n] = c;
        err = 'تعذر تحديث TLE — استُخدمت نسخة مخزَّنة (قد تقل الدقة)';
      } else {
        if (mounted) setState(() => err = 'تعذر تحميل TLE: $e');
        return;
      }
    }
    await refresh();
  }

  Future<void> _sched(int id, String title, String body, double when) async {
    try {
      await fln.zonedSchedule(
          id,
          title,
          body,
          tz.TZDateTime.from(DateTime.fromMillisecondsSinceEpoch((when * 1000).round()), tz.UTC),
          const NotificationDetails(
              android: AndroidNotificationDetails('iss', 'مرور ISS', importance: Importance.high, priority: Priority.high)),
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime);
    } catch (_) {}
  }

  Future<void> refresh() async {
    if (o == null) return;
    _psT = now;
    ps = o!.passes(sel.lat, sel.lon, now);
    try {
      await fln.cancelAll();
    } catch (_) {}
    int id = 1;
    for (final p in ps.take(5)) {
      if (p.aos - 1800 > now) {
        await _sched(id++, '${sat.name} بعد 30 دقيقة',
            'سيمر ${sat.name} فوق ${sel.n} — أقصى ارتفاع ${p.maxEl.round()}°. جهّز الاستماع على ${(fq.hz / 1e6).toStringAsFixed(3)}', p.aos - 1800);
      }
      if (p.aos > now) {
        await _sched(id++, '${sat.name} يبدأ الآن', 'بدأ المرور فوق ${sel.n} — أقصى ارتفاع ${p.maxEl.round()}°', p.aos);
      }
    }
    if (mounted) setState(() {});
  }

  // ───────────── الاستماع ─────────────

  void _load() {
    wc.loadRequest(Uri.parse('${sel.u}?tune=${(curHz / 1e6).toStringAsFixed(3)}${_wsMod(fq.mod)}'));
  }

  /// ضبط يدوي: يحرّك التردد بمقدار delta هرتز (أو يضبطه على القيمة المطلقة abs).
  Future<void> _tuneBy({double? delta, double? abs}) async {
    final nf = (abs ?? (curHz + (delta ?? 0))).clamp(30e6, 3000e6).toDouble();
    cmd = nf;
    log.insert(0, '${DateTime.now().toString().substring(11, 19)}  ${(nf / 1e6).toStringAsFixed(4)} MHz (يدوي)');
    if (log.length > 50) log.removeLast();
    setState(() {});
    if (!listening) return;
    final ok = await _wsTune(nf);
    if (!ok) _load(); // المحطة لا تقبل الضبط الفوري → إعادة تحميل بالتردد الجديد
  }

  void listen() {
    if (recording) stopRec();
    _js(wc, 'window.__sstv&&window.__sstv.finish()'); // احفظ أي صورة جارية قبل إعادة التحميل
    _load();
    if (!screenOff) WakelockPlus.enable(); // يُبقي الشاشة شغّالة كي لا يتوقف الصوت
    _badSecs = 0;
    _deadSecs = 0;
    _reconTries = 0;
    setState(() {
      listening = true;
      audioState = '';
      wsState = '';
      sstvStatus = '';
    });
    _fgSync();
  }

  Pass? _curPass() {
    final t = now;
    for (final p in ps) {
      if (p.aos - 45 <= t && p.los + 5 > t) return p;
    }
    return null;
  }

  Future<void> stop({bool user = true}) async {
    if (user) _declinedAos = _curPass()?.aos;
    if (recording) await stopRec();
    try {
      await wc.runJavaScript('window.__sstv&&window.__sstv.finish()');
    } catch (_) {}
    await Future.delayed(const Duration(milliseconds: 400));
    wc.loadRequest(Uri.parse('about:blank'));
    WakelockPlus.disable();
    if (mounted) {
      setState(() {
        listening = false;
        audioState = '';
      });
    }
    _fgSync();
  }

  void pick(St s) {
    if (listening) stop();
    sel = s;
    sp?.setInt('sel', stations.indexOf(s));
    refresh();
    setState(() => tab = 0);
  }

  // ───────────── إعادة الاتصال والمرور التلقائي ─────────────

  void _scheduleRecon() {
    Future.delayed(const Duration(seconds: 5), () {
      if (listening && autoRecon && _reconTries < 4) {
        _reconTries++;
        log.insert(0, 'إعادة اتصال تلقائية ($_reconTries)');
        _load();
      }
    });
  }

  void _reconTick() {
    if (!autoRecon) return;
    final parts = audioState.split('|');
    final running = audioState.startsWith('running');
    if (!running) {
      _deadSecs = 0;
      _badSecs++;
      if (_badSecs >= 25 && _reconTries < 4) {
        _reconTries++;
        _badSecs = 0;
        log.insert(0, 'إعادة اتصال تلقائية ($_reconTries)');
        _load();
      }
      return;
    }
    _badSecs = 0;
    final lvl = double.tryParse(parts.length > 2 ? parts[2] : '') ?? 1;
    if (lvl < 0.00005) {
      _deadSecs++;
      if (_deadSecs >= 90 && _reconTries < 4) {
        _reconTries++;
        _deadSecs = 0;
        log.insert(0, 'لا صوت منذ 90 ثانية — إعادة اتصال ($_reconTries)');
        _load();
      }
    } else {
      _deadSecs = 0;
      _reconTries = 0;
    }
  }

  void _autoTick() {
    if (o == null) return;
    final t = now;
    Pass? cur;
    for (final p in ps) {
      if (p.maxEl >= minPassEl && p.aos - 45 <= t && p.los + 5 > t) {
        cur = p;
        break;
      }
    }
    if (cur != null) {
      if (!listening && !_autoStarted && cur.aos != _declinedAos) {
        _autoStarted = true;
        if (autoBest) {
          final b = _bestStation(cur);
          if (b != null && b.s != sel) {
            sel = b.s;
            sp?.setInt('sel', stations.indexOf(b.s));
            log.insert(0, 'أفضل محطة لهذا المرور: ${b.s.n} (≈${b.el.round()}°)');
          }
        }
        log.insert(0, 'بدء تلقائي لمرور ${sat.name} (ارتفاع ≈ ${cur.maxEl.round()}°)');
        listen();
        _notifyAuto('بدأ الاستماع التلقائي', '${sat.name} — ${sel.n}');
      }
      if (listening && _autoStarted && autoRec && !recording && audioState.startsWith('running')) {
        startRec();
      }
    } else if (_autoStarted) {
      _autoStarted = false;
      if (listening) {
        log.insert(0, 'انتهى المرور — إيقاف تلقائي');
        stop(user: false);
      }
    }
    if (!listening && cur == null) _declinedAos = null;
  }

  Future<void> _notifyAuto(String title, String body) async {
    try {
      await fln.show(
          800,
          title,
          body,
          const NotificationDetails(
              android: AndroidNotificationDetails('iss', 'مرور ISS', importance: Importance.high, priority: Priority.high)));
    } catch (_) {}
  }

  /// خدمة أمامية تُبقي التطبيق حيًّا: أثناء انتظار مرور تلقائي، أو الاستماع بشاشة مطفأة.
  Future<void> _fgSync() async {
    final want = autoPass || (listening && screenOff);
    final impl = fln.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (impl == null) return;
    try {
      if (want) {
        await impl.startForegroundService(
            77, 'ISS SSTV', listening ? 'الاستماع جارٍ' : 'بانتظار المرور القادم',
            notificationDetails: const AndroidNotificationDetails('iss_fg', 'الخدمة الخلفية',
                importance: Importance.low, priority: Priority.low, ongoing: true),
            foregroundServiceTypes: {AndroidServiceForegroundType.foregroundServiceTypeMediaPlayback});
        _fgOn = true;
      } else if (_fgOn) {
        await impl.stopForegroundService();
        _fgOn = false;
      }
    } catch (_) {
      log.insert(0, 'تعذّر تشغيل الخدمة الخلفية');
    }
  }

  // ───────────── التسجيل ─────────────

  String _2(int n) => n.toString().padLeft(2, '0');
  String _mmss(int s) => '${_2(s ~/ 60)}:${_2(s % 60)}';

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<Directory> _recDir() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/recordings');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  Future<Directory> _imgDir() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/images');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  Future<void> _loadRecs() async {
    try {
      final d = await _recDir();
      final l = d.listSync().whereType<File>().where((f) => f.path.endsWith('.wav')).toList();
      l.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
      if (mounted) setState(() => recs = l);
    } catch (_) {}
  }

  Future<void> _loadImgs() async {
    try {
      final d = await _imgDir();
      final l = d.listSync().whereType<File>().where((f) => f.path.endsWith('.png')).toList();
      l.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
      if (mounted) setState(() => imgs = l);
    } catch (_) {}
  }

  Uint8List _wavHeader(int dataLen, int rate) {
    final b = ByteData(44);
    void s(int o, String t) {
      for (var i = 0; i < t.length; i++) {
        b.setUint8(o + i, t.codeUnitAt(i));
      }
    }

    s(0, 'RIFF');
    b.setUint32(4, 36 + dataLen, Endian.little);
    s(8, 'WAVE');
    s(12, 'fmt ');
    b.setUint32(16, 16, Endian.little);
    b.setUint16(20, 1, Endian.little); // PCM
    b.setUint16(22, 1, Endian.little); // أحادي
    b.setUint32(24, rate, Endian.little);
    b.setUint32(28, rate * 2, Endian.little);
    b.setUint16(32, 2, Endian.little);
    b.setUint16(34, 16, Endian.little);
    s(36, 'data');
    b.setUint32(40, dataLen, Endian.little);
    return b.buffer.asUint8List();
  }

  void _onRec(String m) {
    if (m.isEmpty) return;
    final t = m[0], p = m.substring(1);
    if (t == 'D') {
      final sink = _pcmSink;
      if (recording && sink != null) {
        final bytes = base64Decode(p);
        sink.add(bytes);
        _recBytes += bytes.length;
      }
    } else if (t == 'S') {
      _recRate = int.tryParse(p) ?? 48000;
    } else if (t == 'N') {
      _cancelRec('لا يوجد صوت للتسجيل بعد — ابدأ الاستماع وانتظر حتى يعمل الصوت ثم أعد المحاولة');
    } else if (t == 'M') {
      sstvStatus = p;
      log.insert(0, 'SSTV: $p');
      if (log.length > 50) log.removeLast();
    } else if (t == 'P') {
      final f = p.split('|');
      if (f.length >= 4) {
        liveMode = f[0];
        liveRows = int.tryParse(f[1]) ?? 0;
        liveH = int.tryParse(f[2]) ?? 0;
        try {
          liveImg = base64Decode(f[3]);
        } catch (_) {}
        sstvStatus = 'جارٍ استقبال صورة $liveMode: $liveRows/$liveH';
      }
    } else if (t == 'I') {
      final f = p.split('|');
      if (f.length >= 5) {
        _saveImage(f[0], int.tryParse(f[1]) ?? 0, int.tryParse(f[2]) ?? 0, f[3] == '1', base64Decode(f[4]), true);
      }
    }
  }

  void _onDec(String m) {
    if (m.isEmpty) return;
    final t = m[0], p = m.substring(1);
    if (t == 'I') {
      final f = p.split('|');
      if (f.length >= 5) {
        _decImgs++;
        _saveImage(f[0], int.tryParse(f[1]) ?? 0, int.tryParse(f[2]) ?? 0, f[3] == '1', base64Decode(f[4]), false);
      }
    } else if (t == 'M') {
      if (mounted) setState(() => decMsg = p);
    } else if (t == 'E') {
      final c = _decDone;
      if (c != null && !c.isCompleted) c.complete();
    }
  }

  Future<void> _saveImage(String mode, int rows, int h, bool complete, Uint8List bytes, bool live) async {
    try {
      final d = await _imgDir();
      final ts = DateTime.now();
      final sn = sat.name.replaceAll(RegExp(r'[^A-Za-z0-9\-]'), '');
      final name =
          'sstv_${ts.year}${_2(ts.month)}${_2(ts.day)}_${_2(ts.hour)}${_2(ts.minute)}${_2(ts.second)}_${mode.replaceAll(' ', '')}${complete ? '' : '_partial'}_$sn';
      var f = File('${d.path}/$name.png');
      int k = 1;
      while (await f.exists()) {
        f = File('${d.path}/${name}_${k++}.png');
      }
      await f.writeAsBytes(bytes);
      if (live) {
        liveImg = bytes;
        liveMode = mode;
        liveRows = rows;
        liveH = h;
        sstvStatus = complete ? 'اكتملت صورة $mode وحُفظت في المعرض' : 'حُفظت صورة جزئية ($rows/$h)';
        _notifyAuto('صورة SSTV جديدة', '$mode — $rows/$h');
      }
      await _loadImgs();
      if (mounted) setState(() {});
    } catch (e) {
      _snack('تعذّر حفظ الصورة: $e');
    }
  }

  Future<void> startRec() async {
    if (!listening || recording) return;
    try {
      final d = await _recDir();
      final ts = DateTime.now();
      _recName = 'iss_${ts.year}${_2(ts.month)}${_2(ts.day)}_${_2(ts.hour)}${_2(ts.minute)}${_2(ts.second)}';
      _pcmFile = File('${d.path}/$_recName.pcm');
      _pcmSink = _pcmFile!.openWrite();
      _recBytes = 0;
      _recStart = ts;
      setState(() => recording = true);
      await wc.runJavaScript('window.__issRec?window.__issRec.start():Rec.postMessage("N")');
      Future.delayed(const Duration(seconds: 5), () {
        if (recording && _recBytes == 0) {
          _cancelRec('تعذّر التقاط الصوت من هذه المحطة (لا يصل صوت للتسجيل)');
        }
      });
    } catch (e) {
      _cancelRec('تعذّر بدء التسجيل: $e');
    }
  }

  Future<void> _cancelRec(String msg) async {
    if (!recording) return;
    recording = false;
    final sink = _pcmSink, f = _pcmFile;
    _pcmSink = null;
    _pcmFile = null;
    try {
      await wc.runJavaScript('window.__issRec&&window.__issRec.stop()');
      await sink?.close();
      await f?.delete();
    } catch (_) {}
    if (mounted) setState(() {});
    _snack(msg);
  }

  Future<void> stopRec() async {
    if (!recording) return;
    recording = false;
    try {
      await wc.runJavaScript('window.__issRec&&window.__issRec.stop()');
    } catch (_) {}
    final sink = _pcmSink, pcm = _pcmFile;
    _pcmSink = null;
    _pcmFile = null;
    if (sink == null || pcm == null) {
      if (mounted) setState(() {});
      return;
    }
    try {
      await sink.flush();
      await sink.close();
      if (_recBytes == 0) {
        await pcm.delete();
        _snack('لم يُسجَّل أي صوت');
      } else {
        final wav = File('${pcm.parent.path}/${_recName}_${_recRate}hz.wav');
        final out = wav.openWrite();
        out.add(_wavHeader(_recBytes, _recRate));
        await out.addStream(pcm.openRead());
        await out.close();
        await pcm.delete();
        _snack('تم حفظ التسجيل — تبويب «التسجيلات»');
      }
    } catch (e) {
      _snack('تعذّر حفظ التسجيل: $e');
    }
    await _loadRecs();
    if (mounted) setState(() {});
  }

  String _recTitle(File f) => f.path.split('/').last;

  String _recInfo(File f) {
    final len = f.lengthSync();
    final m = RegExp(r'_(\d+)hz').firstMatch(_recTitle(f));
    final rate = int.tryParse(m?.group(1) ?? '') ?? 48000;
    final secs = ((len - 44) / (rate * 2)).round();
    return 'المدة ${_mmss(secs < 0 ? 0 : secs)}  •  ${(len / 1048576).toStringAsFixed(1)} MB  •  ${f.lastModifiedSync().toString().substring(0, 16)}';
  }

  Future<void> _del(File f) async {
    try {
      await f.delete();
    } catch (_) {}
    await _loadRecs();
  }

  Future<void> _delImg(File f) async {
    try {
      await f.delete();
    } catch (_) {}
    await _loadImgs();
  }

  /// فك SSTV من تسجيل WAV محفوظ (في صفحة مخفية منفصلة).
  Future<void> decodeFile(File f) async {
    if (decBusy) return;
    setState(() {
      decBusy = true;
      decProg = 0;
      decMsg = 'جارٍ التحضير…';
    });
    _decImgs = 0;
    try {
      final bytes = await f.readAsBytes();
      if (bytes.length < 1000) throw Exception('الملف قصير');
      final rate = ByteData.sublistView(bytes).getUint32(24, Endian.little);
      _dcLoaded = Completer<void>();
      await dc.loadHtmlString('<html><body></body></html>');
      await _dcLoaded!.future.timeout(const Duration(seconds: 8), onTimeout: () {});
      await dc.runJavaScript('window.__issCfg={vol:1,sq:0,sstv:1,enh:${enh ? 1 : 0}};');
      await dc.runJavaScript(sstvJs);
      _decDone = Completer<void>();
      const chunk = 240000;
      for (int off = 44; off < bytes.length; off += chunk) {
        final e = math.min(off + chunk, bytes.length);
        final b64 = base64Encode(Uint8List.sublistView(bytes, off, e));
        await dc.runJavaScript("window.__sstv.feedB64('$b64',$rate)");
        if (mounted) {
          setState(() {
            decProg = off / bytes.length;
            decMsg = 'جارٍ الفك…';
          });
        }
      }
      await dc.runJavaScript('window.__sstv.end()');
      await _decDone!.future.timeout(const Duration(seconds: 30), onTimeout: () {});
      _snack(_decImgs > 0 ? 'تم استخراج $_decImgs صورة — تبويب «المعرض»' : 'لم يُعثر على صورة SSTV في هذا التسجيل');
    } catch (e) {
      _snack('تعذّر فك التسجيل: $e');
    }
    await _loadImgs();
    if (mounted) {
      setState(() {
        decBusy = false;
        decMsg = '';
      });
    }
  }

  // ───────────── واجهة ─────────────

  String fmt(double t) => DateTime.fromMillisecondsSinceEpoch((t * 1000).round()).toString().substring(5, 16);

  String dur(double s) {
    s = s.abs();
    final h = s ~/ 3600, m = (s % 3600) ~/ 60, c = (s % 60).floor();
    return h > 0 ? '$hس ${m}د' : '$mد ${c}ث';
  }

  Color _dot(St s) => s.ok == null ? Colors.grey : (s.ok! ? Colors.green : Colors.red);

  Widget _card(String title, IconData ic, List<Widget> kids) => Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(ic, size: 18),
              const SizedBox(width: 8),
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            ]),
            const SizedBox(height: 10),
            ...kids,
          ]),
        ),
      );

  Widget _stat(String l, String v) => Expanded(
        child: Column(children: [
          Text(v, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 2),
          Text(l, style: const TextStyle(fontSize: 12), textAlign: TextAlign.center),
        ]),
      );

  Widget _audioStatus() {
    final parts = audioState.split('|');
    String msg;
    double? lvl;
    Color? col;
    if (audioState.isEmpty || audioState == 'nohook') {
      msg = 'جارٍ تحميل الصفحة…';
    } else if (audioState == 'no-ctx') {
      msg = 'الصفحة لم تبدأ الصوت بعد — فعّل «إظهار صفحة المحطة» واضغط على زر التشغيل فيها، وتأكد أن التردد ضمن نطاق المستقبِل';
      col = Colors.orange;
    } else if (parts[0] != 'running') {
      msg = 'الصوت متوقف (${parts[0]}) — فعّل «إظهار صفحة المحطة» واضغط عليها';
      col = Colors.orange;
    } else {
      lvl = double.tryParse(parts.length > 2 ? parts[2] : '') ?? 0;
      final closed = parts.length > 3 && parts[3] == '0';
      msg = lvl < 0.0005
          ? 'الصوت يعمل لكن المستوى صفر — لا إشارة على هذا التردد (خارج نطاق المستقبِل)'
          : (closed
              ? 'Squelch مغلق (الإشارة أضعف من العتبة)'
              : 'الصوت يصل (المستوى ${lvl.toStringAsFixed(3)}) — إن لم تسمعه ارفع صوت الجهاز');
      col = lvl < 0.0005 ? Colors.orange : Colors.green;
    }
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(msg, style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: col)),
        if (lvl != null)
          Padding(
              padding: const EdgeInsets.only(top: 4),
              child: LinearProgressIndicator(value: (lvl * 8).clamp(0.0, 1.0).toDouble())),
      ]),
    );
  }

  List<Look> _skyPts(Pass p) {
    const n = 48;
    return [for (int i = 0; i <= n; i++) o!.look(p.aos + (p.los - p.aos) * i / n, sel.lat, sel.lon)];
  }

  Widget listenTab() {
    final t = now;
    final f = o?.dop(t, ob, fq.hz) ?? fq.hz;
    final lk = o?.look(t, sel.lat, sel.lon);
    final next = ps.where((p) => p.los > t).toList();
    final tp = next.isNotEmpty ? next.first : null;
    String cd = 'لا توجد مرورات قادمة خلال 48 ساعة';
    double? prog;
    bool live = false;
    if (o == null) {
      cd = err.isEmpty ? 'جارٍ تحميل مدار ${sat.name}…' : err;
    } else if (tp != null) {
      if (tp.aos <= t) {
        live = true;
        cd = '● المرور جارٍ — ينتهي بعد ${dur(tp.los - t)}';
        prog = ((t - tp.aos) / (tp.los - tp.aos)).clamp(0.0, 1.0).toDouble();
      } else {
        cd = 'المرور القادم بعد ${dur(tp.aos - t)}';
      }
    }
    final fg = Theme.of(context).colorScheme.onSurface;
    final accent = Theme.of(context).colorScheme.primary;
    return ListView(padding: const EdgeInsets.all(12), children: [
      _card('المحطة', Icons.cell_tower, [
        Row(children: [
          Icon(Icons.circle, size: 12, color: _dot(sel)),
          const SizedBox(width: 8),
          Expanded(child: Text(sel.n, style: const TextStyle(fontSize: 16))),
          OutlinedButton(onPressed: () => setState(() => tab = 1), child: const Text('تغيير')),
        ]),
      ]),
      _card('القمر والتردد', Icons.satellite_alt, [
        Row(children: [
          Expanded(
              child: DropdownButton<Sat>(
                  isExpanded: true,
                  value: sat,
                  items: [for (final s in sats) DropdownMenuItem(value: s, child: Text('${s.name}  (${s.norad})'))],
                  onChanged: (s) {
                    if (s != null) _pickSat(s);
                  })),
          IconButton(tooltip: 'إضافة قمر', icon: const Icon(Icons.add), onPressed: _addSat),
          if (sat.custom) IconButton(tooltip: 'حذف القمر', icon: const Icon(Icons.delete_outline), onPressed: _delSat),
        ]),
        Wrap(spacing: 8, children: [
          for (final q in sat.fqs)
            ChoiceChip(label: Text(q.label), selected: fq.hz == q.hz, onSelected: (_) => _pickFq(q)),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(
              child: TextField(
                  controller: freqCtl,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(
                      labelText: 'تردد مخصص (MHz) — الحالي ${(fq.hz / 1e6).toStringAsFixed(4)}', isDense: true))),
          const SizedBox(width: 8),
          FilledButton.tonal(onPressed: _applyCustomFreq, child: const Text('تطبيق')),
        ]),
        const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text('تحقّق من حالة القمر وتردده قبل المحاولة؛ ترددات الأقمار تتغير.', style: TextStyle(fontSize: 12))),
      ]),
      _card('المرور والتردد', Icons.satellite_alt, [
        Text(cd, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: live ? Colors.green : null)),
        if (prog != null) Padding(padding: const EdgeInsets.only(top: 8), child: LinearProgressIndicator(value: prog)),
        const SizedBox(height: 12),
        Row(children: [
          _stat('Doppler (MHz)', (f / 1e6).toStringAsFixed(4)),
          _stat('الارتفاع', lk == null ? '—' : '${lk.el.toStringAsFixed(1)}°'),
          _stat('السمت', lk == null ? '—' : '${lk.az.toStringAsFixed(0)}°'),
          _stat('المسافة (كم)', lk == null ? '—' : '${lk.rng.round()}'),
        ]),
        if (lk != null)
          Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(lk.el > 0 ? '● ${sat.name} فوق الأفق الآن' : '○ ${sat.name} تحت الأفق',
                  style: const TextStyle(fontSize: 12))),
      ]),
      _card('الاستماع والتسجيل', Icons.headphones, [
        Text('التردد المضبوط: ${(curHz / 1e6).toStringAsFixed(4)} MHz${cmd == null ? "" : "  (يدوي)"}',
            textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Wrap(spacing: 6, runSpacing: 4, children: [
          for (final d in const [-5000.0, -1000.0, -100.0, 100.0, 1000.0, 5000.0])
            OutlinedButton(
                onPressed: () => _tuneBy(delta: d),
                child: Text('${d > 0 ? "+" : "−"}${d.abs() >= 1000 ? "${(d.abs() / 1000).round()} kHz" : "${d.abs().round()} Hz"}',
                    textDirection: TextDirection.ltr)),
          FilledButton.tonal(
              onPressed: () => _tuneBy(abs: o?.dop(now, ob, fq.hz) ?? fq.hz),
              child: const Text('Doppler الآن')),
          TextButton(onPressed: () => _tuneBy(abs: fq.hz), child: const Text('التردد الاسمي')),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(
              child: FilledButton.icon(
                  onPressed: listen,
                  icon: Icon(listening ? Icons.refresh : Icons.play_arrow),
                  label: Text(listening ? 'إعادة الاتصال' : 'ابدأ الاستماع'))),
          if (listening) ...[
            const SizedBox(width: 8),
            OutlinedButton.icon(onPressed: () => stop(), icon: const Icon(Icons.stop), label: const Text('إيقاف')),
          ],
        ]),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          child: FilledButton.tonalIcon(
            onPressed: listening ? (recording ? stopRec : startRec) : null,
            icon: Icon(recording ? Icons.stop_circle : Icons.fiber_manual_record, color: Colors.red),
            label: Text(recording
                ? 'إيقاف التسجيل  ${_mmss(DateTime.now().difference(_recStart ?? DateTime.now()).inSeconds)}'
                : 'تسجيل الصوت'),
          ),
        ),
        Row(children: [
          const Icon(Icons.volume_up, size: 18),
          Expanded(
              child: Slider(
                  value: vol,
                  min: 0,
                  max: 2,
                  divisions: 20,
                  label: '${(vol * 100).round()}%',
                  onChanged: (v) {
                    setState(() => vol = v);
                    _pushCfg();
                  },
                  onChangeEnd: (_) => _saveSettings())),
        ]),
        Row(children: [
          const Icon(Icons.graphic_eq, size: 18),
          Expanded(
              child: Slider(
                  value: sq,
                  min: 0,
                  max: 0.05,
                  divisions: 25,
                  label: sq == 0 ? 'Squelch: إيقاف' : 'Squelch ${sq.toStringAsFixed(3)}',
                  onChanged: (v) {
                    setState(() => sq = v);
                    _pushCfg();
                  },
                  onChangeEnd: (_) => _saveSettings())),
        ]),
        const Text('الأول: مستوى الصوت (100% = كما هو) • الثاني: Squelch (يكتم الضجيج الأضعف من العتبة)',
            style: TextStyle(fontSize: 11)),
        if (listening) _audioStatus(),
        if (listening)
          SwitchListTile(
              contentPadding: EdgeInsets.zero,
              dense: true,
              value: showPage,
              onChanged: (v) => setState(() => showPage = v),
              title: const Text('إظهار صفحة المحطة (للتشخيص)')),
      ]),
      if (listening || liveImg != null || sstvStatus.isNotEmpty)
        _card('صورة SSTV', Icons.image, [
          Text(
              sstvStatus.isEmpty
                  ? (sstvOn ? 'بانتظار إشارة SSTV… (الفك التلقائي يعمل)' : 'الفك التلقائي متوقف (الإعدادات)')
                  : sstvStatus,
              style: const TextStyle(fontSize: 13)),
          if (liveImg != null)
            Padding(
                padding: const EdgeInsets.only(top: 8),
                child: ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: Image.memory(liveImg!, gaplessPlayback: true, fit: BoxFit.contain))),
          if (liveImg != null && liveMode.isNotEmpty)
            Padding(padding: const EdgeInsets.only(top: 4), child: Text('$liveMode — $liveRows/$liveH صف', style: const TextStyle(fontSize: 12))),
        ]),
      if (tp != null && o != null) ...[
        _card('منظر المرور في السماء', Icons.explore, [
          SizedBox(
              height: 250,
              width: double.infinity,
              child: CustomPaint(painter: SkyPainter(_skyPts(tp), lk, fg, accent))),
          Text('${fmt(tp.aos)} → ${fmt(tp.los)}  •  أقصى ارتفاع ≈ ${tp.maxEl.round()}°  (الشمال في الأعلى)',
              style: const TextStyle(fontSize: 12)),
        ]),
        _card('منحنى Doppler للمرور', Icons.show_chart, [
          SizedBox(
              height: 150,
              width: double.infinity,
              child: CustomPaint(
                  painter: DopplerPainter(
                      [for (int i = 0; i <= 48; i++) tp.aos + (tp.los - tp.aos) * i / 48],
                      [for (int i = 0; i <= 48; i++) o!.dop(tp.aos + (tp.los - tp.aos) * i / 48, ob, fq.hz) - fq.hz],
                      t,
                      fg,
                      accent))),
          const Text('الانحراف عن التردد الاسمي (هرتز) — الخط الأحمر = الآن', style: TextStyle(fontSize: 12)),
        ]),
      ],
      _card('المرورات القادمة', Icons.event, [
        if (next.isEmpty) const Text('—'),
        for (final p in next.take(6))
          ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.schedule),
              title: Text('${fmt(p.aos)} → ${fmt(p.los)}'),
              subtitle: Text('أقصى ارتفاع ≈ ${p.maxEl.round()}°  •  المدة ${dur(p.los - p.aos)}')),
        Text(autoPass ? 'الاستماع التلقائي مفعّل للمرورات ≥ ${minPassEl.round()}°.' : 'الإشعارات: قبل 30 دقيقة وعند بداية المرور.',
            style: const TextStyle(fontSize: 12)),
      ]),
      if (log.isNotEmpty)
        _card('السجل', Icons.history, [
          for (final l in log.take(8)) Text(l, style: const TextStyle(fontSize: 12)),
        ]),
    ]);
  }

  Widget stationsTab() {
    const names = {
      'NL': 'هولندا',
      'DE': 'ألمانيا',
      'PL': 'بولندا',
      'IT': 'إيطاليا',
      'GB': 'بريطانيا',
      'AT': 'النمسا',
      'US': 'أمريكا'
    };
    final groups = <String, List<St>>{};
    for (final s in stations) {
      groups.putIfAbsent(s.cc, () => []).add(s);
    }
    final b = best;
    return ListView(padding: const EdgeInsets.all(12), children: [
      Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Expanded(
                child: Text(
                    'كل المحطات من نوع WebSDR. النقطة الخضراء تعني أن الصفحة تُفتح فقط، ولا تكشف المحطة نطاقها، فجرّب يدويًا. '
                    'محطات HF قد لا تغطي 145/437 MHz — اختر محطة VHF/UHF. علامة (≈) = إحداثيات تقريبية.',
                    style: TextStyle(fontSize: 12))),
            IconButton(
                tooltip: 'إعادة فحص المحطات',
                icon: const Icon(Icons.refresh),
                onPressed: () {
                  setState(() {
                    for (final s in stations) {
                      s.ok = null;
                    }
                  });
                  _check();
                }),
          ]),
        ),
      ),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.emoji_events, size: 18),
              const SizedBox(width: 8),
              const Expanded(child: Text('أفضل محطة للمرور القادم', style: TextStyle(fontWeight: FontWeight.bold))),
              FilledButton.tonal(
                  onPressed: () {
                    final nx = ps.where((p) => p.los > now).toList();
                    setState(() => best = _bestStation(nx.isEmpty ? null : nx.first));
                    if (best == null) _snack('لا نتيجة (تأكد من تحميل المدار)');
                  },
                  child: const Text('احسب')),
            ]),
            if (b != null) ...[
              const SizedBox(height: 8),
              Text('${b.s.n} — أقصى ارتفاع ≈ ${b.el.round()}° — ${b.note}'),
              const SizedBox(height: 4),
              Align(alignment: AlignmentDirectional.centerStart, child: OutlinedButton(onPressed: () => pick(b.s), child: const Text('اختيار هذه المحطة'))),
            ],
          ]),
        ),
      ),
      for (final e in groups.entries) ...[
        Padding(
            padding: const EdgeInsets.fromLTRB(4, 12, 4, 4),
            child: Text(names[e.key] ?? e.key, style: const TextStyle(fontWeight: FontWeight.bold))),
        for (final s in e.value) _stationTile(s),
      ],
    ]);
  }

  Widget _stationTile(St s) {
    final cv = s.coverage(fq.hz);
    final covTxt = s.ws ? '' : (cv.s == 'y' ? '  •  يغطي ${(fq.hz / 1e6).toStringAsFixed(3)}' : (cv.s == 'n' ? '  •  لا يغطي التردد' : ''));
    return Card(
      child: ListTile(
        selected: s == sel,
        leading: Icon(Icons.circle, size: 14, color: _dot(s)),
        title: Text(s.approx ? '${s.n} ≈' : s.n),
        subtitle: Text(
            'WebSDR  •  ${s.ok == null ? "جارٍ الفحص…" : (s.ok! ? "الصفحة تعمل" : "لا تستجيب")}${s.unv ? "  •  غير مؤكدة" : ""}$covTxt',
            style: TextStyle(color: cv.s == 'y' ? Colors.green : (cv.s == 'n' ? Colors.red : null))),
        trailing: s == sel ? const Icon(Icons.check_circle) : null,
        onTap: () => pick(s),
      ),
    );
  }

  List<List<LatLng>> _segs(List<LatLng> pts) {
    final lines = <List<LatLng>>[[]];
    for (final p in pts) {
      if (lines.last.isNotEmpty && (p.longitude - lines.last.last.longitude).abs() > 180) lines.add([]);
      lines.last.add(p);
    }
    return lines;
  }

  Widget mapTab() {
    if (o == null) return Center(child: Text(err.isEmpty ? 'جارٍ تحميل المدار...' : err));
    final t = now;
    if (t - _trackT > 30) {
      _trackT = t;
      _past = _segs([for (double d = -2700; d <= 0; d += 60) o!.ll(t + d)]);
      _fut = _segs([for (double d = 0; d <= 6000; d += 60) o!.ll(t + d)]);
    }
    final pos = o!.ll(t);
    final h = o!.alt(t);
    final foot = 6371 * math.acos(6371 / (6371 + h)) * 1000; // نصف قطر منطقة الرؤية (متر)
    return FlutterMap(
      options: MapOptions(
        initialCenter: mapCenter,
        initialZoom: mapZoom,
        onPositionChanged: (cam, _) {
          mapCenter = cam.center;
          mapZoom = cam.zoom;
        },
      ),
      children: [
        TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: appId),
        CircleLayer(circles: [
          CircleMarker(
              point: pos,
              radius: foot,
              useRadiusInMeter: true,
              color: Colors.deepOrange.withOpacity(0.12),
              borderColor: Colors.deepOrange,
              borderStrokeWidth: 1.5),
        ]),
        PolylineLayer(polylines: [
          for (final l in _past) Polyline(points: l, strokeWidth: 2, color: Colors.deepOrange.withOpacity(0.35)),
          for (final l in _fut) Polyline(points: l, strokeWidth: 2, color: Colors.deepOrange),
        ]),
        MarkerLayer(markers: [
          Marker(point: pos, width: 36, height: 36, child: const Icon(Icons.satellite_alt, color: Colors.red, size: 32)),
          Marker(point: LatLng(sel.lat, sel.lon), width: 30, height: 30, child: const Icon(Icons.location_on, color: ink)),
        ]),
        const SimpleAttributionWidget(source: Text('OpenStreetMap contributors')),
      ],
    );
  }

  Widget galleryTab() => imgs.isEmpty
      ? const Center(
          child: Padding(
              padding: EdgeInsets.all(32),
              child: Text('لا توجد صور بعد.\nتُحفظ هنا صور SSTV المفكوكة تلقائيًا أثناء الاستماع، أو من «فك SSTV» في التسجيلات.',
                  textAlign: TextAlign.center)))
      : GridView.builder(
          padding: const EdgeInsets.all(10),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: 0.9),
          itemCount: imgs.length,
          itemBuilder: (c, i) {
            final f = imgs[i];
            final nm = f.path.split('/').last;
            return GestureDetector(
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute<void>(builder: (_) => ImgViewer(file: f, onDelete: () => _delImg(f)))),
              child: Card(
                clipBehavior: Clip.antiAlias,
                child: Column(children: [
                  Expanded(child: Image.file(f, fit: BoxFit.cover, width: double.infinity, cacheWidth: 500)),
                  Padding(
                      padding: const EdgeInsets.all(6),
                      child: Text(nm.replaceFirst('sstv_', '').replaceFirst('.png', ''),
                          maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10))),
                ]),
              ),
            );
          });

  Widget recsTab() => ListView(padding: const EdgeInsets.all(12), children: [
        const Card(
            child: Padding(
                padding: EdgeInsets.all(14),
                child: Text(
                    'التسجيلات بصيغة WAV (16-bit أحادي). زر الصورة يفك SSTV من التسجيل ويحفظ النتيجة في «المعرض»، '
                    'وزر المشاركة يرسل الملف لبرنامج آخر (MMSSTV وغيره).',
                    style: TextStyle(fontSize: 12)))),
        if (decBusy)
          Card(
              child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(decMsg.isEmpty ? 'جارٍ الفك…' : decMsg),
                    const SizedBox(height: 6),
                    LinearProgressIndicator(value: decProg),
                  ]))),
        if (recs.isEmpty) const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('لا توجد تسجيلات بعد'))),
        for (final f in recs)
          Card(
            child: ListTile(
              leading: const Icon(Icons.audiotrack),
              title: Text(_recTitle(f), textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 13)),
              subtitle: Text(_recInfo(f), style: const TextStyle(fontSize: 12)),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                IconButton(
                    tooltip: 'فك SSTV',
                    icon: const Icon(Icons.image_search),
                    onPressed: decBusy ? null : () => decodeFile(f)),
                IconButton(icon: const Icon(Icons.share), onPressed: () => Share.shareXFiles([XFile(f.path)])),
                IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _del(f)),
              ]),
            ),
          ),
      ]);

  @override
  Widget build(BuildContext c) {
    final dock = listening && tab == 0 && showPage;
    final dockH = (MediaQuery.of(c).size.height * 0.38).clamp(240.0, 380.0).toDouble();
    final Widget body = switch (tab) {
      0 => listenTab(),
      1 => stationsTab(),
      2 => mapTab(),
      3 => galleryTab(),
      _ => recsTab(),
    };
    return Scaffold(
      appBar: AppBar(
        title: const Text('ISS SSTV Tracker'),
        actions: [
          if (recording)
            const Padding(padding: EdgeInsets.all(16), child: Icon(Icons.fiber_manual_record, color: Colors.red, size: 14)),
          IconButton(tooltip: 'الإعدادات', icon: const Icon(Icons.settings), onPressed: _openSettings),
        ],
      ),
      body: Stack(children: [
        Padding(padding: EdgeInsets.only(bottom: dock ? dockH : 0), child: body),
        // نفس الـ WebView دائمًا (لا يُعاد إنشاؤه): لوحة ظاهرة في تبويب الاستماع، وبكسل واحد في غيره كي يستمر الصوت
        Positioned(
          left: 0,
          bottom: 0,
          right: dock ? 0 : null,
          width: dock ? null : 1,
          height: dock ? dockH : 1,
          child: Opacity(opacity: dock ? 1 : 0.01, child: ClipRect(child: WebViewWidget(controller: wc))),
        ),
        // صفحة مخفية لفك SSTV من التسجيلات
        Positioned(
          left: 0,
          top: 0,
          width: 1,
          height: 1,
          child: Opacity(opacity: 0.01, child: WebViewWidget(controller: dc)),
        ),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) {
          setState(() => tab = i);
          if (i == 3) _loadImgs();
          if (i == 4) _loadRecs();
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.headphones), label: 'الاستماع'),
          NavigationDestination(icon: Icon(Icons.cell_tower), label: 'المحطات'),
          NavigationDestination(icon: Icon(Icons.public), label: 'الخريطة'),
          NavigationDestination(icon: Icon(Icons.photo_library), label: 'المعرض'),
          NavigationDestination(icon: Icon(Icons.library_music), label: 'التسجيلات'),
        ],
      ),
    );
  }
}
