import 'dart:math' as math;
import 'package:latlong2/latlong.dart';

const rad = math.pi / 180;
const minEl = 5.0; // أقل ارتفاع يُعتبر مرورًا صالحًا (درجات)

class V {
  final double x, y, z;
  V(this.x, this.y, this.z);
  V operator -(V o) => V(x - o.x, y - o.y, z - o.z);
  double get l => math.sqrt(x * x + y * y + z * z);
  double dot(V o) => x * o.x + y * o.y + z * o.z;
}

V obsV(double la, double lo) => V(6371 * math.cos(la * rad) * math.cos(lo * rad),
    6371 * math.cos(la * rad) * math.sin(lo * rad), 6371 * math.sin(la * rad));

class Pass {
  final double aos, los, maxEl;
  Pass(this.aos, this.los, this.maxEl);
}

class Look {
  final double el, az, rng;
  Look(this.el, this.az, this.rng);
}

/// مدار شبه دائري من TLE + انجراف J2 (تقريبي، مناسب للمرورات وDoppler).
class Orb {
  late final double inc, raan, argp, m0, n, ep, a, k;
  Orb(String l1, String l2) {
    double d(int s, int e) => double.parse(l2.substring(s, e).trim());
    inc = d(8, 16) * rad;
    raan = d(17, 25) * rad;
    argp = d(34, 42) * rad;
    m0 = d(43, 51) * rad;
    n = d(52, 63) * 2 * math.pi / 86400;
    final y = int.parse(l1.substring(18, 20));
    ep = DateTime.utc(y < 57 ? 2000 + y : 1900 + y).millisecondsSinceEpoch / 1000 +
        (double.parse(l1.substring(20, 32)) - 1) * 86400;
    a = math.pow(398600.4418 / (n * n), 1 / 3).toDouble();
    k = 1.5 * 1.08263e-3 * math.pow(6378.137 / a, 2).toDouble();
  }

  V ecef(double t) {
    final dt = t - ep;
    final c = math.cos(inc);
    final om = raan - k * n * c * dt;
    final u = m0 + argp + n * (1 + k * (4 * c * c - 1)) * dt;
    final x = a * (math.cos(om) * math.cos(u) - math.sin(om) * c * math.sin(u));
    final y = a * (math.sin(om) * math.cos(u) + math.cos(om) * c * math.sin(u));
    final z = a * math.sin(inc) * math.sin(u);
    final g = ((280.46061837 + 360.98564736629 * (t / 86400 + 2440587.5 - 2451545.0)) % 360) * rad;
    return V(x * math.cos(g) + y * math.sin(g), -x * math.sin(g) + y * math.cos(g), z);
  }

  LatLng ll(double t) {
    final s = ecef(t);
    return LatLng(math.asin(s.z / s.l) / rad, math.atan2(s.y, s.x) / rad);
  }

  double alt(double t) => ecef(t).l - 6371;

  double el(double t, V ob) {
    final r = ecef(t) - ob;
    return math.asin(r.dot(ob) / (r.l * ob.l)) / rad;
  }

  /// الارتفاع والسمت والمسافة من موقع المراقب.
  Look look(double t, double la, double lo) {
    final r = ecef(t) - obsV(la, lo);
    final sl = math.sin(la * rad), cl = math.cos(la * rad);
    final so = math.sin(lo * rad), co = math.cos(lo * rad);
    final e = -so * r.x + co * r.y;
    final nn = -sl * co * r.x - sl * so * r.y + cl * r.z;
    final u = cl * co * r.x + cl * so * r.y + sl * r.z;
    final rng = r.l;
    return Look(math.asin(u / rng) / rad, (math.atan2(e, nn) / rad + 360) % 360, rng);
  }

  double dop(double t, V ob, double f) {
    final r1 = (ecef(t) - ob).l, r2 = (ecef(t + 1) - ob).l;
    return f * (1 - (r2 - r1) / 299792.458);
  }

  /// لحظة عبور الارتفاع [lv] بين a وb بالتنصيف (دقة أقل من ثانية).
  double _cross(V ob, double t1, double t2, double lv) {
    final sideA = el(t1, ob) > lv;
    for (int i = 0; i < 12; i++) {
      final m = (t1 + t2) / 2;
      if ((el(m, ob) > lv) == sideA) {
        t1 = m;
      } else {
        t2 = m;
      }
    }
    return (t1 + t2) / 2;
  }

  List<Pass> passes(double la, double lo, double t0, {double hours = 48}) {
    final ob = obsV(la, lo);
    final out = <Pass>[];
    double? aos;
    double mx = 0;
    double pt = t0, pe = el(t0, ob);
    if (pe > minEl) {
      aos = t0;
      mx = pe;
    }
    for (double t = t0 + 20; t < t0 + hours * 3600; t += 20) {
      final e = el(t, ob);
      if (aos == null && e > minEl && pe <= minEl) aos = _cross(ob, pt, t, minEl);
      if (e > minEl) mx = math.max(mx, e);
      if (aos != null && e <= minEl && pe > minEl) {
        out.add(Pass(aos, _cross(ob, pt, t, minEl), mx));
        aos = null;
        mx = 0;
      }
      pt = t;
      pe = e;
    }
    return out;
  }
}
