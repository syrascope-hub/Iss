/// تردد هبوط (Hz) + نمط التضمين (nfm / usb / lsb).
class Fq {
  final String label;
  final double hz;
  final String mod;
  const Fq(this.label, this.hz, [this.mod = 'nfm']);
  Map<String, dynamic> toJson() => {'l': label, 'h': hz, 'm': mod};
  static Fq fromJson(Map<String, dynamic> j) => Fq(j['l'] as String, (j['h'] as num).toDouble(), j['m'] as String);
}

class Sat {
  final String name;
  final int norad;
  final List<Fq> fqs;
  final bool custom;
  const Sat(this.name, this.norad, this.fqs, {this.custom = false});
}

/// تحقّق من حالة كل قمر وتردده قبل الاستخدام (ترددات الأقمار تتغير).
const builtinSats = <Sat>[
  Sat('ISS', 25544, [Fq('145.800 SSTV', 145800000), Fq('437.550 SSTV', 437550000)]),
  Sat('SO-50', 27607, [Fq('436.795 FM', 436795000)]),
  Sat('FO-29', 24278, [Fq('435.850 SSB', 435850000, 'usb')]),
  Sat('AO-7', 7530, [Fq('145.950 SSB', 145950000, 'usb')]),
];

/// نتيجة فحص تغطية محطة OpenWebRX لتردد معيّن: y = تغطي، n = لا تغطي، ? = غير معروف.
class Cov {
  final String s;
  final Map<String, dynamic>? p;
  const Cov(this.s, this.p);
}

class St {
  final String n, u, cc;
  final bool unv; // غير مؤكدة (لم تُفحص)
  final bool ws;
  final double? la, lo;
  final bool approx; // إحداثيات تقريبية (على مستوى المدينة/الدولة) — صحّحها إن عرفت الموقع
  bool? ok;
  List<Map<String, dynamic>>? profs; // ملفات (Profiles) المحطة من status.json
  St(this.n, this.u, {this.cc = '', this.unv = false, this.ws = false, this.la, this.lo, this.approx = false});
  double get lat => la ?? 52.129;
  double get lon => lo ?? 5.019;

  String get base => u.endsWith('/') ? u : '$u/';

  Cov coverage(double hz) {
    final l = profs;
    if (ws || l == null || l.isEmpty) return const Cov('?', null);
    for (final p in l) {
      final c = p['center_freq'];
      final sr = p['samp_rate'] ?? p['sample_rate'];
      if (c is! num || sr is! num) continue;
      if ((hz - c.toDouble()).abs() <= sr.toDouble() / 2 * 0.95) return Cov('y', p);
    }
    return const Cov('n', null);
  }
}

final stations = <St>[
  St('Maasbree WebSDR NL — الأساسية', 'http://sdr.websdrmaasbree.nl:8909/', cc: 'NL', ws: true, la: 51.35, lo: 6.05),
  St('Twente WebSDR NL', 'http://websdr.ewi.utwente.nl:8901/', cc: 'NL', ws: true, unv: true, la: 52.239, lo: 6.857),
  St('Hack Green HF WebSDR UK', 'http://hackgreensdr.org:8901/', cc: 'GB', ws: true, unv: true, la: 53.04, lo: -2.54, approx: true),
  St('Hack Green VHF/UHF WebSDR UK', 'http://hackgreensdr.org:8902/', cc: 'GB', ws: true, unv: true, la: 53.04, lo: -2.54, approx: true),
  St('Goonhilly VHF/UHF UK', 'https://vhf-goonhilly.batc.org.uk/', cc: 'GB', ws: true, unv: true, la: 50.05, lo: -5.18, approx: true),
  St('TU Graz WebSDR AT', 'https://websdr.iks.tugraz.at/', cc: 'AT', ws: true, unv: true, la: 47.07, lo: 15.45, approx: true),
  St('Northern Utah WebSDR US', 'https://www.sdrutah.org/', cc: 'US', ws: true, unv: true, la: 41.55, lo: -112.12, approx: true),
];
