# ISS SSTV Tracker

## البناء عبر GitHub Actions (الأسهل)
1. ارفع محتويات هذا المجلد إلى مستودع GitHub (الفرع `main`).
2. ملف `.github/workflows/build.yml` يولّد مجلد android تلقائيًا ويعدّل الأذونات
   (INTERNET، POST_NOTIFICATIONS، RECEIVE_BOOT_COMPLETED، WAKE_LOCK، cleartext، مستقبِلات الإشعارات، desugaring، minSdk 23)
   عبر `tool/patch_android.py` ثم يبني APK.
3. نزّل `iss-sstv-tracker-apk` من تبويب Actions → Artifacts.

## البناء محليًا
```
flutter create . --platforms=android --org com.astro --project-name iss_sstv_tracker
# (أعد pubspec.yaml و lib/main.dart من هذا المشروع إن استُبدلا)
python3 tool/patch_android.py
flutter pub get
flutter run
```
Flutter الموصى به: 3.24.x.

## ما الجديد في 1.1
- إحداثيات للمحطات الثلاث الناقصة (تقريبية، علامة ≈ — صحّحها).
- TLE مخزَّن 6 ساعات مع رجوع للمخزَّن عند انقطاع الشبكة.
- مرورات لـ 48 ساعة، حد أدنى للارتفاع 5°، وAOS/LOS بدقة أقل من ثانية.
- عدّاد تنازلي، السمت، المسافة، منطقة رؤية ISS ومسار سابق على الخريطة.
- إشعار قبل 30 دقيقة وعند بدء المرور (أول 5 مرورات).
- إبقاء الشاشة مضاءة أثناء الاستماع، وزر إيقاف، وإيقاف الصوت عند تغيير المحطة.
- بناء التبويب الحالي فقط (أداء أفضل)، وحفظ المحطة المختارة.

## للتجربة على الجهاز
- هل يتفاعل OpenWebRX مع تغيير `location.hash` أثناء التشغيل؟ جرّب محطتين.
- هل المحطة المختارة تغطي 437 MHz؟
- التردد `f0` في `main.dart` (437.550) — تأكد منه لكل حدث (ARISS SSTV المعتاد 145.800).
- إشعار "عند البدء" قد يتأخر دقائق لأن الجدولة غير دقيقة (inexact) لتجنب إذن المنبّهات الدقيقة.
