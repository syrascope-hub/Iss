import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:satellite_dart/io.dart';
import 'package:satellite_dart/propagation/gstime.dart';
import 'package:satellite_dart/propagation/propagate.dart';
import 'package:satellite_dart/transforms.dart';
import 'extras.dart';

void main() => runApp(const App());

const cream = Color(0xFFF5EBD7), ink = Color(0xFF111111);
const maasbree = LatLng(51.355, 5.887); // approx. station location
const maasbreeUrl = 'http://sdr.websdrmaasbree.nl:8909/m.html';
const issTle = 'https://celestrak.org/NORAD/elements/gp.php?CATNR=25544&FORMAT=TLE';
const amateurTle = 'https://celestrak.org/NORAD/elements/gp.php?GROUP=amateur&FORMAT=TLE';

class Sat {
  final String name;
  final Map<String, dynamic> rec;
  Sat(this.name, this.rec);
}

Future<List<Sat>> loadSats(String url, {int max = 40}) async {
  final body = (await http.get(Uri.parse(url))).body.trim().split('\n');
  final out = <Sat>[];
  for (var i = 0; i + 2 < body.length && out.length < max; i += 3) {
    out.add(Sat(body[i].trim(), twoline2satrec(body[i + 1].trim(), body[i + 2].trim())));
  }
  return out;
}

// Position in ECF (km) at time t.
List<double> ecf(Sat s, DateTime t) {
  final pv = propagate(s.rec, t);
  final e = eciToEcf(pv['position'], gstime(t));
  return [(e['x'] as num).toDouble(), (e['y'] as num).toDouble(), (e['z'] as num).toDouble()];
}

List<double> obsEcf(LatLng p) {
  const a = 6378.137;
  final la = p.latitudeRad, lo = p.longitudeRad;
  return [a * cos(la) * cos(lo), a * cos(la) * sin(lo), a * sin(la)];
}

double dist(List<double> a, List<double> b) =>
    sqrt(pow(a[0] - b[0], 2) + pow(a[1] - b[1], 2) + pow(a[2] - b[2], 2));

double elevation(Sat s, DateTime t, LatLng obs) {
  final o = obsEcf(obs), p = ecf(s, t);
  final r = [p[0] - o[0], p[1] - o[1], p[2] - o[2]];
  final n = sqrt(o[0] * o[0] + o[1] * o[1] + o[2] * o[2]);
  final sinEl = (r[0] * o[0] + r[1] * o[1] + r[2] * o[2]) / (n * dist(p, o));
  return asin(sinEl) * 180 / pi;
}

LatLng subPoint(Sat s, DateTime t) {
  final p = ecf(s, t);
  return LatLng(atan2(p[2], sqrt(p[0] * p[0] + p[1] * p[1])) * 180 / pi,
      atan2(p[1], p[0]) * 180 / pi);
}

class Pass {
  final DateTime start, end;
  final double maxEl;
  Pass(this.start, this.end, this.maxEl);
}

List<Pass> passes(Sat s, LatLng obs, {int hours = 24, double minEl = 5}) {
  final out = <Pass>[];
  var t = DateTime.now().toUtc();
  final stop = t.add(Duration(hours: hours));
  DateTime? st;
  var mx = 0.0;
  for (; t.isBefore(stop); t = t.add(const Duration(seconds: 20))) {
    final el = elevation(s, t, obs);
    if (el > 0) {
      st ??= t;
      mx = max(mx, el);
    } else if (st != null) {
      if (mx >= minEl) out.add(Pass(st, t, mx));
      st = null;
      mx = 0;
    }
  }
  return out;
}

// Doppler-corrected receive frequency in Hz.
double dopplerHz(Sat s, DateTime t, LatLng obs, double f0) {
  final o = obsEcf(obs);
  final r1 = dist(ecf(s, t), o);
  final r2 = dist(ecf(s, t.add(const Duration(seconds: 1))), o);
  const c = 299792.458;
  return f0 * (1 - (r2 - r1) / c);
}

// ---- Receiver engines: native first, hidden WebView as fallback ----
abstract class SdrEngine {
  String get label;
  Future<bool> connect();
  Future<void> setFrequency(double hz);
}

class NativeEngine implements SdrEngine {
  @override
  String get label => 'Native WebSDR';
  WebSocket? _ws;
  @override
  Future<bool> connect() async {
    // UNVERIFIED: WebSDR's stream protocol is undocumented. This only probes
    // the socket; until decoding is implemented it reports failure so the
    // app falls back to the hidden engine.
    try {
      _ws = await WebSocket.connect('ws://sdr.websdrmaasbree.nl:8909/~~stream')
          .timeout(const Duration(seconds: 6));
      await _ws!.close();
    } catch (_) {}
    return false;
  }

  @override
  Future<void> setFrequency(double hz) async {}
}

class HiddenWebViewEngine implements SdrEngine {
  @override
  String get label => 'Hidden WebView engine';
  @override
  Future<bool> connect() async {
    // TODO(device test): load maasbreeUrl in an off-screen WebViewController,
    // start audio, and expose tuning via runJavaScript. Needs the page's real
    // tuning function name, which must be checked on the live page.
    return false;
  }

  @override
  Future<void> setFrequency(double hz) async {
    // TODO: send tuning command (hz / 1000 kHz) to the page.
  }
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          scaffoldBackgroundColor: cream,
          colorScheme: ColorScheme.fromSeed(seedColor: ink, surface: cream),
          appBarTheme: const AppBarTheme(backgroundColor: ink, foregroundColor: cream),
        ),
        home: const Home(),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;
  List<Sat> iss = [], ham = [];
  String err = '';

  @override
  void initState() {
    super.initState();
    () async {
      try {
        iss = await loadSats(issTle, max: 1);
        ham = await loadSats(amateurTle);
      } catch (e) {
        err = 'TLE load failed: $e';
      }
      if (mounted) setState(() {});
    }();
  }

  @override
  Widget build(BuildContext c) {
    final pages = [MapTab(iss: iss, ham: ham), PassTab(iss: iss), RxTab(iss: iss), const RecTab(), const AiTab()];
    return Scaffold(
      appBar: AppBar(title: const Text('ISS SSTV Tracker')),
      body: err.isNotEmpty ? Center(child: Text(err)) : pages[tab],
      bottomNavigationBar: NavigationBar(
        backgroundColor: ink,
        indicatorColor: cream,
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.public, color: cream), label: 'Map'),
          NavigationDestination(icon: Icon(Icons.schedule, color: cream), label: 'Passes'),
          NavigationDestination(icon: Icon(Icons.radio, color: cream), label: 'Receiver'),
          NavigationDestination(icon: Icon(Icons.mic, color: cream), label: 'Record'),
          NavigationDestination(icon: Icon(Icons.auto_awesome, color: cream), label: 'AI'),
        ],
      ),
    );
  }
}

class MapTab extends StatefulWidget {
  final List<Sat> iss, ham;
  const MapTab({super.key, required this.iss, required this.ham});
  @override
  State<MapTab> createState() => _MapTabState();
}

class _MapTabState extends State<MapTab> {
  Timer? tm;
  @override
  void initState() {
    super.initState();
    tm = Timer.periodic(const Duration(seconds: 3), (_) => setState(() {}));
  }

  @override
  void dispose() {
    tm?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) {
    final now = DateTime.now().toUtc();
    final track = widget.iss.isEmpty
        ? <LatLng>[]
        : [for (var m = 0; m <= 90; m += 2) subPoint(widget.iss.first, now.add(Duration(minutes: m)))];
    // split at the antimeridian so the line doesn't cross the whole map
    final segs = <List<LatLng>>[[]];
    for (final p in track) {
      if (segs.last.isNotEmpty && (p.longitude - segs.last.last.longitude).abs() > 180) segs.add([]);
      segs.last.add(p);
    }
    return FlutterMap(
      options: const MapOptions(initialCenter: maasbree, initialZoom: 2),
      children: [
        TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'iss_sstv_tracker'),
        PolylineLayer(polylines: [for (final s in segs) Polyline(points: s, color: ink, strokeWidth: 2)]),
        MarkerLayer(markers: [
          const Marker(point: maasbree, child: Icon(Icons.cell_tower, color: Colors.red)),
          for (final s in widget.ham)
            Marker(point: subPoint(s, now), width: 24, height: 24, child: const Icon(Icons.circle, size: 8, color: Colors.teal)),
          if (widget.iss.isNotEmpty)
            Marker(point: subPoint(widget.iss.first, now), width: 36, height: 36, child: const Icon(Icons.satellite_alt, color: ink)),
        ]),
      ],
    );
  }
}

class PassTab extends StatelessWidget {
  final List<Sat> iss;
  const PassTab({super.key, required this.iss});
  @override
  Widget build(BuildContext c) {
    if (iss.isEmpty) return const Center(child: CircularProgressIndicator());
    final list = passes(iss.first, maasbree);
    return ListView(children: [
      const ListTile(title: Text('Maasbree station'), subtitle: Text('Next 24 h, min elevation 5°')),
      for (final p in list)
        ListTile(
          leading: const Icon(Icons.north_east),
          title: Text('${_f(p.start.toLocal())} → ${_f(p.end.toLocal())}'),
          subtitle: Text('Max elevation ${p.maxEl.toStringAsFixed(0)}°'),
        ),
    ]);
  }

  String _f(DateTime t) => '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
}

class RxTab extends StatefulWidget {
  final List<Sat> iss;
  const RxTab({super.key, required this.iss});
  @override
  State<RxTab> createState() => _RxTabState();
}

class _RxTabState extends State<RxTab> {
  double base = 437.550; // MHz, editable; ISS SSTV is often 145.800
  double current = 0, lastSent = 0;
  String status = 'Not connected';
  SdrEngine? engine;
  Timer? tm;
  final ctl = TextEditingController(text: '437.550');

  Future<void> start() async {
    for (final e in [NativeEngine(), HiddenWebViewEngine()]) {
      setState(() => status = 'Trying ${e.label}…');
      if (await e.connect()) {
        engine = e;
        break;
      }
    }
    setState(() => status = engine == null
        ? 'No engine could control the receiver yet (see TODOs). Doppler values below are calculated only.'
        : 'Connected via ${engine!.label}');
    tm = Timer.periodic(const Duration(seconds: 1), (_) => tick());
  }

  void tick() {
    if (widget.iss.isEmpty) return;
    final s = widget.iss.first, now = DateTime.now().toUtc();
    if (elevation(s, now, maasbree) < 0) {
      setState(() => current = 0);
      return;
    }
    final f = dopplerHz(s, now, maasbree, base * 1e6);
    // retune in 5 kHz steps so the frequency never jumps
    final stepped = (f / 5000).round() * 5000.0;
    if (stepped != lastSent) {
      lastSent = stepped;
      engine?.setFrequency(stepped);
    }
    setState(() => current = stepped);
  }

  @override
  void dispose() {
    tm?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          TextField(
            controller: ctl,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Base frequency (MHz)'),
            onChanged: (v) => base = double.tryParse(v) ?? base,
          ),
          const SizedBox(height: 24),
          Text(current == 0 ? 'ISS below horizon' : '${(current / 1e6).toStringAsFixed(3)} MHz',
              style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Text(status, textAlign: TextAlign.center),
          const SizedBox(height: 24),
          FilledButton(onPressed: tm == null ? start : null, child: const Text('Start auto-tracking')),
        ]),
      );
}
