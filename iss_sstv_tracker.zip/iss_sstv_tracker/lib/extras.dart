import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AiTab extends StatefulWidget {
  const AiTab({super.key});
  @override
  State<AiTab> createState() => _AiTabState();
}

class _AiTabState extends State<AiTab> {
  final key = TextEditingController();
  final q = TextEditingController(text: 'What ISS SSTV or ARISS events are planned soon?');
  String answer = '';
  bool busy = false;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) => key.text = p.getString('or_key') ?? '');
  }

  Future<void> ask() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('or_key', key.text.trim());
    setState(() {
      busy = true;
      answer = '';
    });
    try {
      final r = await http.post(
        Uri.parse('https://openrouter.ai/api/v1/chat/completions'),
        headers: {'Authorization': 'Bearer ${key.text.trim()}', 'Content-Type': 'application/json'},
        body: jsonEncode({
          // ':online' lets OpenRouter add web results so dates are current
          'model': 'openrouter/auto:online',
          'messages': [
            {'role': 'system', 'content': 'You help amateur radio users find ISS SSTV and ARISS events. Give dates, frequencies and sources.'},
            {'role': 'user', 'content': q.text},
          ],
        }),
      );
      final j = jsonDecode(utf8.decode(r.bodyBytes));
      answer = j['choices']?[0]?['message']?['content'] ?? 'Error: ${r.body}';
    } catch (e) {
      answer = 'Error: $e';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext c) => ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: key, obscureText: true, decoration: const InputDecoration(labelText: 'OpenRouter API key')),
        TextField(controller: q, decoration: const InputDecoration(labelText: 'Question')),
        const SizedBox(height: 12),
        FilledButton(onPressed: busy ? null : ask, child: Text(busy ? '…' : 'Search events')),
        const SizedBox(height: 12),
        SelectableText(answer),
      ]);
}

class RecTab extends StatefulWidget {
  const RecTab({super.key});
  @override
  State<RecTab> createState() => _RecTabState();
}

class _RecTabState extends State<RecTab> {
  final rec = AudioRecorder();
  bool on = false;
  String last = '';

  Future<void> toggle() async {
    if (on) {
      last = await rec.stop() ?? '';
      setState(() => on = false);
      return;
    }
    if (!await rec.hasPermission()) return;
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/rec_${DateTime.now().millisecondsSinceEpoch}.wav';
    await rec.start(const RecordConfig(encoder: AudioEncoder.wav, sampleRate: 48000, numChannels: 1), path: path);
    setState(() => on = true);
  }

  @override
  void dispose() {
    rec.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          IconButton.filled(iconSize: 56, onPressed: toggle, icon: Icon(on ? Icons.stop : Icons.mic)),
          const SizedBox(height: 12),
          Text(on ? 'Recording WAV…' : 'Tap to record (mic / speaker audio)'),
          if (last.isNotEmpty) Padding(padding: const EdgeInsets.all(16), child: SelectableText('Saved: $last')),
        ]),
      );
}
