# ISS SSTV Tracker (core)

1. flutter create --org com.example --project-name iss_sstv_tracker tmp && cp -r tmp/android tmp/.metadata . && rm -rf tmp
2. In android/app/src/main/AndroidManifest.xml add inside <manifest>:
   <uses-permission android:name="android.permission.INTERNET"/>
   <uses-permission android:name="android.permission.RECORD_AUDIO"/>
   and on <application> add: android:usesCleartextTraffic="true"  (Maasbree is http)
3. flutter pub get && flutter run

Status: map, pass calculator, Doppler maths, mic WAV recording and OpenRouter events search are implemented.
NOT done: real WebSDR tuning (engines in lib/main.dart are stubs, see TODOs), SSTV audio->image, pass notifications, extra station list.
Untested: written without a Flutter SDK or network; satellite_dart call names may need small fixes.
